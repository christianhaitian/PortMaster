Anarch

Anarch is extremely small, completely public domain, no-dependency, no-file, portable suckless anarcho-pacifist from-scratch 90s-style Doom clone that runs everywhere, made for the benefit of all living beings.

Developer: Miloslav Číž / drummyfish 
URL: https://drummyfish.itch.io/anarch

CONTROLS
=========

dpad up = forward
dpad down = backward
dpad left = left
dpad right = right

left_analog_up = look up
left_analog_down = look down
left_analog_left = look left
left_analog_right = look right
left_analog_press = lock/unlock look left/right

right_analog_up = look up
right_analog_down = look down
right_analog_left = look left
right_analog_right = look right
right_analog_press = attack/fire/confirm

l1 = rotate weapon 
r1 = rotate weapon

y + dpad left = rotate weapon
y + dpad right = rotate weapon
y + dpad down = menu

b + dpad up = look up
b + dpad down = look down
b + dpad left = strafe left
b + dpad right = strafe right

x = attack/fire/confirm
a = jump

start = menu
select/back = map



