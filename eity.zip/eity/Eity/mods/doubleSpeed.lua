doubleSpeed = {}

function doubleSpeed.ApplyMod()
  return 1.25
end

return doubleSpeed
