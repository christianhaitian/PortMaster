halfSpeed = {}

function halfSpeed.ApplyMod()
  return 0.75
end

return halfSpeed
