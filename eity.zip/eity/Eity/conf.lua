function love.conf(t)
    t.window.title ="Eity"
    t.window.icon = "assets/Eity_icon.png"
    t.window.vsync = false
end
