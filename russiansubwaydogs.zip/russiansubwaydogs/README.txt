Russian Subway Dogs
https://store.steampowered.com/app/762610/Russian_Subway_Dogs/

Controls: 
dpad/l-stick = movement
x = bark
a = bark and jump
b = jump

ported by mattyj513