#!/bin/bash

ESUDO="sudo"
if [ -f "/storage/.config/.OS_ARCH" ]; then
  ESUDO=""
fi

if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
  sdl_controllerconfig="03000000091200000031000011010000,OpenSimHardware OSH PB Controller,a:b0,b:b1,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,dpup:h0.1,leftx:a0~,lefty:a1~,guide:b12,leftstick:b8,lefttrigger:b10,rightstick:b9,back:b7,start:b6,rightx:a2,righty:a3,righttrigger:b11,platform:Linux,"
  param_device="anbernic"
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      sdl_controllerconfig="190000004b4800000010000001010000,GO-Advance Gamepad (rev 1.1),a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b9,dpleft:b10,dpright:b11,dpup:b8,leftx:a0,lefty:a1,back:b12,leftstick:b13,lefttrigger:b14,rightstick:b16,righttrigger:b15,start:b17,platform:Linux,"
      param_device="oga"
      if [ ! -f "/roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg" ]; then
        mv -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480 /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg
        rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640
        rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480.2analogs
        rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640.2analogs
	  fi
	else
	  sdl_controllerconfig="190000004b4800000010000000010000,GO-Advance Gamepad,a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b7,dpleft:b8,dpright:b9,dpup:b6,leftx:a0,lefty:a1,back:b10,lefttrigger:b12,righttrigger:b13,start:b15,platform:Linux,"
	  param_device="rk2020"
      if [ ! -f "/roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg" ]; then
        mv -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480 /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg
        rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640
        rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480.2analogs
        rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640.2analogs
	  fi
	fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  sdl_controllerconfig="190000004b4800000011000000010000,GO-Super Gamepad,platform:Linux,x:b2,a:b1,b:b0,y:b3,back:b12,guide:b14,start:b13,dpleft:b10,dpdown:b9,dpright:b11,dpup:b8,leftshoulder:b4,lefttrigger:b6,rightshoulder:b5,righttrigger:b7,leftstick:b15,rightstick:b16,leftx:a0,lefty:a1,rightx:a2,righty:a3,platform:Linux,"
  param_device="ogs"
  if [ ! -f "/roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg" ]; then
    mv -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640.2analogs /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg
    rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480
    rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480.2analogs
    rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640
  fi
else
  sdl_controllerconfig="19000000030000000300000002030000,gameforce_gamepad,leftstick:b14,rightx:a3,leftshoulder:b4,start:b9,lefty:a0,dpup:b10,righty:a2,a:b1,b:b0,guide:b16,dpdown:b11,rightshoulder:b5,righttrigger:b7,rightstick:b15,dpright:b13,x:b2,back:b8,leftx:a1,y:b3,dpleft:b12,lefttrigger:b6,platform:Linux,"
  param_device="chi"
  if [ ! -f "/roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg" ]; then
    mv -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640.2analogs /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg
    rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480
    rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480.2analogs
    rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640
  fi
fi

# This if statement is needed to check for ArkOS on the 351V when using the second sd card slot
if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  if [ ! -f "/roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg" ] && [ -f "/boot/rk3326-rg351v-linux.dtb" ]; then
    mv -f /roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640 /roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg
    rm -f /roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480
    rm -f /roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480.2analogs
    rm -f /roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640.2analogs
  fi
  $ESUDO rm -rf ~/.config/rednukem
  $ESUDO ln -s /roms2/ports/rednukem-redneck2/conf/rednukem ~/.config/
  cd /roms2/ports/rednukem-redneck2/
  $ESUDO ./oga_controls rednukem $param_device &
  LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./rednukem -game_dir /roms2/ports/rednukem-redneck2/gamedata -gamegrp REDNECK.GRP 2>&1 | tee ./log.txt
  $ESUDO kill -9 $(pidof oga_controls)
  $ESUDO systemctl restart oga_events &
  printf "\033c" >> /dev/tty1
elif [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ] && [ -f "/boot/rk3326-rg351mp-linux.dtb" ]; then
  if [ ! -f "/roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg" ]; then
    mv -f /roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640.2analogs /roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg
    rm -f /roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480
    rm -f /roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480.2analogs
    rm -f /roms2/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640
  fi
  $ESUDO rm -rf ~/.config/rednukem
  $ESUDO ln -s /roms2/ports/rednukem-redneck2/conf/rednukem ~/.config/
  cd /roms2/ports/rednukem-redneck2/
  $ESUDO ./oga_controls rednukem $param_device &
  LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./rednukem -game_dir /roms2/ports/rednukem-redneck2/gamedata -gamegrp REDNECK.GRP 2>&1 | tee ./log.txt
  $ESUDO kill -9 $(pidof oga_controls)
  $ESUDO systemctl restart oga_events &
  printf "\033c" >> /dev/tty1
else
  # This if statement is needed to check for TheRA on the 351V
  if [ -f "/boot/rk3326-rg351v-linux.dtb" ] || [ -f "/boot/rk3326-rg351v-linux.dtb" ] || [ $(cat "/storage/.config/.OS_ARCH") == "RG351V" ]; then
    if [ ! -f "/roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg" ]; then
      mv -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640 /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg
      rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480
      rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480.2analogs
      rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640.2analogs
    fi
  else
    if [ ! -f "/roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg" ]; then
      mv -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480.2analogs /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg
      rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640
      rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.480
      rm -f /roms/ports/rednukem-redneck2/conf/rednukem/rednukem.cfg.640.2analogs
	fi
  fi
  $ESUDO rm -rf ~/.config/rednukem
  $ESUDO ln -s /roms/ports/rednukem-redneck2/conf/rednukem ~/.config/
  cd /roms/ports/rednukem-redneck2/
  $ESUDO ./oga_controls rednukem $param_device &
  LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./rednukem -game_dir /roms/ports/rednukem-redneck2/gamedata -gamegrp REDNECK.GRP 2>&1 | tee ./log.txt
  $ESUDO kill -9 $(pidof oga_controls)
  $ESUDO systemctl restart oga_events &
  printf "\033c" >> /dev/tty1
fi