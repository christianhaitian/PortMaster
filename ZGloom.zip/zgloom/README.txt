ZGloom

ZGloom is a re-implementation of Amiga FPS Gloom, including support for Gloom 3, Gloom Deluxe and Zombie Massacre.

Gloom was released as is from developers - https://github.com/earok/GloomAmiga
Gloom 3 was released by developers - http://aminet.net/package/game/shoot/UltimateGloomISO
Zombie Massacre was released by developers - http://aminet.net/package/game/shoot/ZombieMassacreISO
Gloom Deluxe is a 1 level demo - http://aminet.net/package.php?package=game/demo/Gloom_Deluxe.dms


Developer: Swizpig (https://github.com/Swizpig)
URL: https://github.com/Swizpig/ZGloom

Cheat system backported from https://github.com/JetStreamSham/ZGloom-vita


CONTROLS
========

Dpad, left and right stick movement

Menu - A,B,X,Y - Confirm

Game -  A,B,X,Y - Fire

Start - Menu

Start + Select = Exit