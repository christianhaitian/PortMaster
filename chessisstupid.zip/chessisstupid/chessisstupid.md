
## Notes

Thanks to Harley Wilson at https://hwilson.itch.io/chess-is-stupid for creating the game and allowing us to distribute the files.

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement |
| r-stick| shoot |
| start| pause/skip |