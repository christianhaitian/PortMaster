#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

chmod 666 /dev/tty1

if [ ! -f /$directory/ports/iortcw/conf/.wolf/main/wolfconfig.cfg ]; then
  if [ "$LOWRES" == "Y" ]; then 
    mv -f /$directory/ports/iortcw/conf/.wolf/main/wolfconfig.cfg.480 /$directory/ports/iortcw/conf/.wolf/main/wolfconfig.cfg
    rm -f /$directory/ports/iortcw/conf/.wolf/main/wolfconfig.cfg.*
  elif [[ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG552" ]] || [[ -e "/dev/input/by-path/platform-singleadc-joypad-event-joystick" ]]; then 
    mv -f /$directory/ports/iortcw/conf/.wolf/main/wolfconfig.cfg.rg552 /$directory/ports/iortcw/conf/.wolf/main/wolfconfig.cfg
    rm -f /$directory/ports/iortcw/conf/.wolf/main/wolfconfig.cfg.* 
  else
    mv -f /$directory/ports/iortcw/conf/.wolf/main/wolfconfig.cfg.640 /$directory/ports/iortcw/conf/.wolf/main/wolfconfig.cfg
    rm -f /$directory/ports/iortcw/conf/.wolf/main/wolfconfig.cfg.*
  fi
fi

rm -rf ~/.wolf
ln -sfv /$directory/ports/iortcw/conf/.wolf/ ~/
cd /$directory/ports/iortcw
$ESUDO chmod 666 /dev/uinput
$GPTOKEYB "iowolfsp.aarch64" &
SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./iowolfsp.aarch64 2>&1 | tee ./log.txt
$ESUDO kill -9 $(pidof gptokeyb)
systemctl restart oga_events &
printf "\033c" > /dev/tty1