#!/bin/bash

whichos=$(grep "title=" "/usr/share/plymouth/themes/text.plymouth")
if [[ $whichos == *"RetroOZ"* ]]; then
  raloc="/opt/retroarch/bin"
else 
  raloc="/usr/local/bin"
fi

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  GAMEDIR="/roms2/ports/dinothawr"
else
  GAMEDIR="/roms/ports/dinothawr"
fi

$raloc/retroarch -L $GAMEDIR/dinothawr_libretro.so $GAMEDIR/dinothawr.game
