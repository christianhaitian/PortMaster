# Contributors

## Version 2

- [@cxong](https://github.com/cxong) helped with initial design of version 2.
- [@paladin-t](https://github.com/paladin-t) helped with initial design of version 2.
- [@r-lyeh](https://github.com/r-lyeh) helped with initial design of version 2.

## Version 1

- [@ratchetfreak](https://github.com/ratchetfreak) added `pquaternion_null`/`quaternion_null` and `pquaternion_from_2_vectors`/`quaternion_from_2_vectors`
- [@ratchetfreak](https://github.com/ratchetfreak) found bug with function for quaternion inverse
- [@ratchetfreak](https://github.com/ratchetfreak) found bug with function for testing if quaternion is zero
- [@cxong](https://github.com/cxong) suggested functions to test vectors equality
- [@cxong](https://github.com/cxong) suggested function to return zeroed vectors
- [@cxong](https://github.com/cxong) fixed typos in `REFERENCE.md`
- [@Ankush-p](https://github.com/Ankush-p) added `pmatrix_transpose`/`matrix_transpose` and `pmatrix_inverse`/`matrix_inverse`
- [@Ankush-p](https://github.com/Ankush-p) fixed `pmatrix_rotation_axis`/`matrix_rotation_axis`
- [@barrotsteindev](https://github.com/barrotsteindev) added Travis CI integration
- [@Randy Gaul](https://github.com/RandyGaul) helped giving useful suggestions
