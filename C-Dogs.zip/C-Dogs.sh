#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

if [[ $LOWRES == "Y" ]]; then
      if [ ! -f "/roms/ports/cdogs/conf/cdogs-sdl/options.cnf" ]; then
        mv -f /roms/ports/cdogs/conf/cdogs-sdl/options.cnf.480 /roms/ports/cdogs/conf/cdogs-sdl/options.cnf
        rm -f /roms/ports/cdogs/conf/cdogs-sdl/options.cnf.*
      fi
elif [[ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG552" ]] || [[ -e "/dev/input/by-path/platform-singleadc-joypad-event-joystick" ]]; then
  if [ ! -f "/roms/ports/cdogs/conf/cdogs-sdl/options.cnf" ]; then
    mv -f /roms/ports/cdogs/conf/cdogs-sdl/options.cnf.rg552 /roms/ports/cdogs/conf/cdogs-sdl/options.cnf
    rm -f /roms/ports/cdogs/conf/cdogs-sdl/options.cnf.*
  fi
elif [[ $param_device == "ogs" ]]; then
  if [ ! -f "/roms/ports/cdogs/conf/cdogs-sdl/options.cnf" ]; then
    mv -f /roms/ports/cdogs/conf/cdogs-sdl/options.cnf.ogs /roms/ports/cdogs/conf/cdogs-sdl/options.cnf
    rm -f /roms/ports/cdogs/conf/cdogs-sdl/options.cnf.*
  fi
else
  if [ ! -f "/roms/ports/cdogs/conf/cdogs-sdl/options.cnf" ]; then
    mv -f /roms/ports/cdogs/conf/cdogs-sdl/options.cnf.640 /roms/ports/cdogs/conf/cdogs-sdl/options.cnf
    rm -f /roms/ports/cdogs/conf/cdogs-sdl/options.cnf.*
  fi
fi

chmod 666 /dev/tty1

rm -rf ~/.config/cdogs-sdl
ln -sfv /$directory/ports/cdogs/conf/cdogs-sdl/ ~/.config/
cd /$directory/ports/cdogs/data
$controlfolder/oga_controls cdogs-sdl $param_device &
./cdogs-sdl
kill -9 $(pidof oga_controls)
systemctl restart oga_events &
printf "\033c" > /dev/tty1
