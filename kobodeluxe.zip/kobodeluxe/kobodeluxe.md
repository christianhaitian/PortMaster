## Notes

Thanks to [David Olofson](https://github.com/olofson/kobodeluxe) for this updated and enhance version of XKobo.

## Controls

| Button | Action |
|--|--| 
|Dpad|Movement|
|A/B/X/Y|Action/Shoot|
|Select|Pause|
|Start/|Back/Menu|
|Start+Select|Quit|


