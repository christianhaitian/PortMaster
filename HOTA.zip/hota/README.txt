Native port of Heart of The Alien

https://github.com/M-HT/hota

Dpad/Lstick - Up/Down/Left/Right
A -  Shoot/Run
B -  Jump
X -  Fast Forward
Y -  Whip
L1/2 - Quick Load
R1/2 - Quick Save
Select - Escape

Press A to skip intro or X to fast forwad. Select OK on code selection screen to start gameplay.

Put the following in the data folder:

Heart Of The Alien (U).iso
Heart Of The Alien (U) xx.ogg or Heart Of The Alien (U) xx.mp3 (xx = 02-42)