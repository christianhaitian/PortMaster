#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

GAMEDIR=/$directory/ports/rvgl

cd $GAMEDIR

if [ ! -f $GAMEDIR/rvgl ]; then
  $ESUDO ./install_rvgl.py

  if [ -f $GAMEDIR/rvgl ]; then    # if installed, setup libraries and copy profile data for portmaster
    $ESUDO cp -f $GAMEDIR/.versions/rvgl_version.txt $GAMEDIR/.versions/rvgl_assets.txt    # version for assets
    $ESUDO cp -f $GAMEDIR/.versions/rvgl_version.txt $GAMEDIR/.versions/rvgl_linux.txt    # version for linux
    $ESUDO cp -f $GAMEDIR/lib/libarm64/libenet.so.7 $GAMEDIR/lib/libenet.so.7    # copy libraries
    $ESUDO cp -f $GAMEDIR/lib/libarm64/libopenal.so.1 $GAMEDIR/lib/libopenal.so.1    # copy libraries
    $ESUDO cp -f $GAMEDIR/lib/libarm64/libunistring.so.2 $GAMEDIR/lib/libunistring.so.2    # copy libraries
    $ESUDO mv -f $GAMEDIR/portmaster/profiles/ark $GAMEDIR/profiles/ark    # copy profile
    $ESUDO mv -f $GAMEDIR/portmaster/profiles/gamecontrollerdb.txt $GAMEDIR/profiles/gamecontrollerdb.txt    # copy rk3326 game controller configuration file
    cp -f $GAMEDIR/profiles/rvgl.ini $GAMEDIR/profiles/rvgl.bak    # backup settings file, if setup was run
    $ESUDO mv -f $GAMEDIR/portmaster/profiles/rvgl.ini $GAMEDIR/profiles/rvgl.ini    # replace settings file
    $ESUDO cp -f $GAMEDIR/portmaster/rvgl $GAMEDIR/rvgl    # replace rvgl script to ensure libenet.so.7 works
    rm -d -r $GAMEDIR/portmaster
  else
    exit
  fi

fi

$ESUDO chmod 666 /dev/uinput
$GPTOKEYB "rvgl.arm64" -c "./rvgl.gptk" &
$GAMEDIR/rvgl
$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1