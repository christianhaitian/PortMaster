## Installation
Download the game at https://linky439.itch.io/f-zero-pocket and unzip the Tracks folder and the EXE to the f-zeropocket/gamedata folder. An install script will take care of the rest.

## Default Gameplay Controls
| Button | Action |
|--|--|
|D-PAD / Analog|Move|
|UP|Boost|
|A|Accelerate|
|B|Brake|
|START|Pause|

## Thanks
MadShmupper  
Tekkenfede  
Testers and Devs from the PortMaster Discord  
(Linky439)[https://linky439.itch.io/f-zero-pocket] for the amazing game!




