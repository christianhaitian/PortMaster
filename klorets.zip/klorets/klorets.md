
## Notes

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement  |
| a| regular attack/cancel |
| b| fast attack/confirm |
| x/y| hyper |