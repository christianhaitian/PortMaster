class Player:
  def __init__(self):
    self.addr = ("0.0.0.0", 0)