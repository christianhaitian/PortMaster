Xenon Valkyrie
https://store.steampowered.com/app/573780/Xenon_Valkyrie/
"Xenon Valkyrie is a rogue-like with many RPG elements in which you will have to get to the deepest part of a moon and finish the plans of a wicked witch. You will be able to get many weapons randomly as you fight in a world that is created every time you play."

Controls: 
dpad = movement
a = ok/jump 
b = cancel
x = attack
y/l1/r1 = change weapons 
up = talk/enter/use
down = down bridge  

ported by mattyj513