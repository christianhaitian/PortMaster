
## Notes

Thanks to Harley Wilson at https://hwilson.itch.io/bowling-cross-final-frame for creating the game and allowing us to distribute.

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement|
| a| confirm/bowl |
| b| cancel/skip |
| start| pause |
