#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

GAMEDIR=$directory/ports/hcl

$ESUDO rm -rf ~/.hydracastlelabyrinth
ln -sfv /$GAMEDIR/conf/.hydracastlelabyrinth ~/

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  cd /roms2/ports/hcl
  ./oga_controls hcl $param_device &
  SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./hcl
  kill -9 $(pidof oga_controls)
  systemctl restart oga_events &
else
  cd /roms/ports/hcl
  ./oga_controls hcl $param_device &
  SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./hcl
  kill -9 $(pidof oga_controls)
  systemctl restart oga_events &
fi

printf "\033c" >> /dev/tty1