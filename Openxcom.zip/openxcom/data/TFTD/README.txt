Copy all the X-COM: Terror From the Deep subfolders to this directory!

If you can't write to this directory, you can also create a TFTD folder in your
user folder (where your OpenXcom savegames are) and copy your TFTD subfolders
there.

After the copy, this directory should contain at least the following items:
  ANIMS*
  FLOP_INT*
  GEODATA
  GEOGRAPH
  MAPS
  ROUTES
  SOUND
  TERRAIN
  UFOGRAPH
  UNITS
*optional

If you want to import your old games, copy the GAME_* folders to the
directory where your OpenXcom saves are.