## Notes

Download version 4.0.21 from https://d.apkpure.com/b/APK/com.butakov.psebay?versionCode=4000021, rename to psebay.apk, place in /ports/psebay

## Controls

|Button| Action |
|--|--|
| A| accelerate/select  |
| B| brake/cancel |
| X| reverse |
| d-pad/l-stick L/R| lean |
| Start| pause |
| L2/R2| alt rev/acc |