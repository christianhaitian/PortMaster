Doom 3 Portmaster ReadMe
*Based on the work from: https://github.com/gabrielcuvillier/d3wasm
*This requires Portmaster to be installed to work: https://351elec.de/PortMaster
*This will not run on rk3326 devices 
*Place your pk4 files in base/
	They should read as follows:
		base/
			pak000.pk4
			pak001.pk4
			pak002.pk4
			pak003.pk4
			pak004.pk4
			pak005.pk4
			pak006.pk4
			pak007.pk4
			
This also comes with the flashlight ductape mod, if you do not want this mod remove:
			pak0008.pk4
			
