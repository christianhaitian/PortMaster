Doom 3 Portmaster ReadMe
*Based on the work from: https://github.com/emileb/d3es-multithread
*Built at commit ref: 4f35e6ad2acafb936b784a9d33c8383864ce91a8
*This requires Portmaster to be installed to work
*This will not run on rk3326 devices 
*Place your pk4 files in base/
	They should read as follows:
		base/
			pak000.pk4
			pak001.pk4
			pak002.pk4
			pak003.pk4
			pak004.pk4
			pak005.pk4
			pak006.pk4
			pak007.pk4
			pak008.pk4
			
