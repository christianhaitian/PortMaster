#!/bin/bash


if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

if [[ $LOWRES == "Y" ]]; then
  if [ ! -f "/roms/ports/nxengine-evo/conf/nxengine/settings.dat" ]; then
    mv -f /roms/ports/nxengine-evo/conf/nxengine/settings.dat.480 /roms/ports/nxengine-evo/conf/nxengine/settings.dat
    rm -f /roms/ports/nxengine-evo/conf/nxengine/settings.dat.*
  fi
elif [[ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG552" ]] || [[ -e "/dev/input/by-path/platform-singleadc-joypad-event-joystick" ]]; then
  if [ ! -f "/roms/ports/nxengine-evo/conf/nxengine/settings.dat" ]; then
    mv -f /roms/ports/nxengine-evo/conf/nxengine/settings.dat.rg552 /roms/ports/nxengine-evo/conf/nxengine/settings.dat
    rm -f /roms/ports/nxengine-evo/conf/nxengine/settings.dat.*
  fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  param_device="ogs"
  if [ ! -f "/roms/ports/nxengine-evo/conf/nxengine/settings.dat" ]; then
    mv -f /roms/ports/nxengine-evo/conf/nxengine/settings.dat.ogs /roms/ports/nxengine-evo/conf/nxengine/settings.dat
    rm -f /roms/ports/nxengine-evo/conf/nxengine/settings.dat.*
  fi
else
  if [ ! -f "/roms/ports/nxengine-evo/conf/nxengine/settings.dat" ]; then
    mv -f /roms/ports/nxengine-evo/conf/nxengine/settings.dat.640 /roms/ports/nxengine-evo/conf/nxengine/settings.dat
    rm -f /roms/ports/nxengine-evo/conf/nxengine/settings.dat.*
  fi
fi

$ESUDO rm -rf ~/.local/share/nxengine
$ESUDO ln -s /$directory/ports/nxengine-evo/conf/nxengine ~/.local/share/
cd /$directory/ports/nxengine-evo
$ESUDO $controlfolder/oga_controls nxengine-evo $param_device &
LD_LIBRARY_PATH="$LD_LIBRARY_PATH:/$directory/ports/nxengine-evo/libs" SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./nxengine-evo
$ESUDO kill -9 $(pidof oga_controls)
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1
