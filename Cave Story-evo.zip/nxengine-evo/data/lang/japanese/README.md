# Japanese translation for nxengine-evo
## Note: this repo is for translators only. Ready to use translations are are in https://github.com/nxengine/translations

Well, that's not an actual translation, really, just an original scripts decoded and converted to UTF-8.  
However, i slightly modified TextBox.pbm, to make yesno box same size as in english version,  
because all other translations use it as base and i really don't want to change sprites.sif for Japanese only.

Plus, there's translations for menu, etc.


