# Chinese (Simplified) translation for nxengine-evo
## Note: this repo is for translators only. Ready to use translations are are in https://github.com/nxengine/translations

Translated by Hydrowing (game) and Rita Gubina (menus).