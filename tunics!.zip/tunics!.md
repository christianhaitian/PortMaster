## Installation
Download game from https://solarus-games.org/games/tunics/ and put the .solarus file in tunics!/game.

## Default Gameplay Controls
| Button | Action |
|--|--|
|D-PAD|Move|
|A|Interact|
|B|Attack||
|X|Item 2|
|Y|Item 1|
|L1|Map|
|START|Inventory|
|SELECT|Pause|

## Thanks
Cebion  
Testers and Devs from the PortMaster Discord  




