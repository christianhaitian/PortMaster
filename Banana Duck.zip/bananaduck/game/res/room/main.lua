game.hideSplash = true
ldtk:level("Loader")