
## Notes

## Controls

|Button| Action |
|--|--|
| l-stick/r-stick| aim |
| a/r1| shoot  |
| b/x/l1| dash |
| y| skip intro |