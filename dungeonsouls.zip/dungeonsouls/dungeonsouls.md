
## Notes

## Controls

|Button| Action |
|--|--|
| l-stick| movement |
| r-stick| aim |
| R1| primary attack |
| R2/L1/L2| unlockable attacks/abilities |
| A| select/pick up |
| B| map |
| X| level up | 
| Y| Stats |
| dpad| use items |
| select| pause |