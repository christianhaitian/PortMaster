
## Notes

Thanks to Harley Wilson at https://hwilson.itch.io/king-of-machines for creating the game and allowing us to distribute.

## Controls

|Button| Action |
|--|--|
| d-pad| movement |
| a| jump/confirm |
| b| melee |
| x| jump |
| y| shoot |
| r1| break charge |
| r2/l2| special weapons |
| start| pause |