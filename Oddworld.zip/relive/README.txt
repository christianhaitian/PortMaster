Abe's Oddysee
=============
From the original game files, copy *.lvl and *.ddv files to 'oddysee' directory.

Abe's Exoddus
=============
From the original game files, copy sounds.dat, *.lvl and *.ddv files to 'exoddus' directory.
