NOTE: Let the intro play the first time you start the game. It creates cache
files needed by the game.

From the original game (The Secret Files and/or The Christmas Chronicles),
you need to copy at least the following files/directories to
/roms/ports/jazz2/Source:

Directories:
  Tiles
  UserLevels

Files:
  *.j2?
  *.it
  *.mod
  *.s3m

cp -r Tiles UserLevels *.j2? *.it *.mod *.s3m $SDCARD/ports/jazz2/Source
