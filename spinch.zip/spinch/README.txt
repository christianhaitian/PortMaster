Spinch
https://store.steampowered.com/app/794240/Spinch/
"Transcend the material realm and assume your true form as Spinch, a hyper-agile organism consumed by the quest to rescue a litter of its missing offspring, in this side-scrolling, psychedelic platformer from the mind of award-winning Canadian cartoonist, Jesse Jacobs."

Controls: 
dpad/L stick = movement
a/b = jump
x/y = dash

ported by mattyj513