
## Notes

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement |
| a| jump/confirm|
| b| shoot |
| select| skip |
