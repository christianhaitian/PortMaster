#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

cd /$directory/ports/openclaw

if [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]] && [ "$ANALOGSTICKS" != "2" ]; then
  sed -i '/width\=\"640\"/s//width\=\"480\"/g' /$directory/ports/openclaw/config.xml
  sed -i '/height\=\"480\"/s//height\=\"320\"/g' /$directory/ports/openclaw/config.xml
else
  sed -i '/width\=\"480\"/s//width\=\"640\"/g' /$directory/ports/openclaw/config.xml
  sed -i '/height\=\"320\"/s//height\=\"480\"/g' /$directory/ports/openclaw/config.xml
fi
$ESUDO chmod 666 /dev/uinput
$GPTOKEYB "openclaw" -c "./openclaw.gptk.1" &
LD_LIBRARY_PATH="$PWD/libs" SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./openclaw 2>&1 | tee -a ./log.txt
$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1
