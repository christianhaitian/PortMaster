#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

GAMEDIR="/$directory/ports/openclaw"
cd $GAMEDIR

if [ "$LOWRES" == "Y" ]; then
  sed -i '/width\=\"1920\"/s//width\=\"480\"/g' $GAMEDIR/config.xml
  sed -i '/width\=\"857\"/s//width\=\"480\"/g' $GAMEDIR/config.xml
  sed -i '/width\=\"640\"/s//width\=\"480\"/g' $GAMEDIR/config.xml
  sed -i '/height\=\"1080\"/s//height\=\"320\"/g' $GAMEDIR/config.xml
  sed -i '/height\=\"480\"/s//height\=\"320\"/g' $GAMEDIR/config.xml
  sed -i '/<Scale>3/s//<Scale>1/g' $GAMEDIR/config.xml
elif [[ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG552" ]] || [[ -e "/dev/input/by-path/platform-singleadc-joypad-event-joystick" ]]; then
  sed -i '/width\=\"857\"/s//width\=\"1920\"/g' $GAMEDIR/config.xml
  sed -i '/width\=\"640\"/s//width\=\"1920\"/g' $GAMEDIR/config.xml
  sed -i '/width\=\"480\"/s//width\=\"1920\"/g' $GAMEDIR/config.xml
  sed -i '/height\=\"480\"/s//height\=\"1080\"/g' $GAMEDIR/config.xml
  sed -i '/height\=\"320\"/s//height\=\"1080\"/g' $GAMEDIR/config.xml
  sed -i '/<Scale>1/s//<Scale>3/g' $GAMEDIR/config.xml
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  sed -i '/width\=\"1920\"/s//width\=\"857\"/g' $GAMEDIR/config.xml
  sed -i '/width\=\"640\"/s//width\=\"857\"/g' $GAMEDIR/config.xml
  sed -i '/width\=\"480\"/s//width\=\"857\"/g' $GAMEDIR/config.xml
  sed -i '/height\=\"1080\"/s//height\=\"480\"/g' $GAMEDIR/config.xml
  sed -i '/height\=\"320\"/s//height\=\"480\"/g' $GAMEDIR/config.xml
  sed -i '/<Scale>3/s//<Scale>1/g' $GAMEDIR/config.xml
else
  sed -i '/width\=\"1920\"/s//width\=\"640\"/g' $GAMEDIR/config.xml
  sed -i '/width\=\"857\"/s//width\=\"640\"/g' $GAMEDIR/config.xml
  sed -i '/width\=\"480\"/s//width\=\"640\"/g' $GAMEDIR/config.xml
  sed -i '/height\=\"1080\"/s//height\=\"480\"/g' $GAMEDIR/config.xml
  sed -i '/height\=\"320\"/s//height\=\"480\"/g' $GAMEDIR/config.xml
  sed -i '/<Scale>3/s//<Scale>1/g' $GAMEDIR/config.xml
fi

$ESUDO chmod 666 /dev/tty1
$ESUDO chmod 666 /dev/uinput
$GPTOKEYB "openclaw" -c "$GAMEDIR/openclaw.gptk.1" &
LD_LIBRARY_PATH="$GAMEDIR/libs" SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./openclaw 2>&1 | tee $GAMEDIR/log.txt
$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1
