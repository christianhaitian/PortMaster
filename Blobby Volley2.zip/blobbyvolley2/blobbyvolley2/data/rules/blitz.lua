__AUTHOR__ = "chameleon"
__TITLE__  = "Crazy Volley - Blitz"
SCORE_TO_WIN = 2
