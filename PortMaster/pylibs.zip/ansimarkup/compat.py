try:
    import builtins
except ImportError:
    import __builtin__ as builtins  # noqa


__all__ = 'builtins'
