import sys
import pytest
import sdl2

# NOTE: Will need to use a window fixture to test most of these. Will also want
# to mark most as "SKIP_ANNOYING".


@pytest.mark.skip("not implemented")
def test_SDL_GetMouseFocus():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_GetMouseState():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_GetRelativeMouseState():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_WarpMouseInWindow():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_SetRelativeMouseMode():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_GetRelativeMouseMode():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_CreateCursor():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_CreateColorCursor():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_CreateSystemCursor():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_SetCursor():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_GetCursor():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_GetDefaultCursor():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_FreeCursor():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_ShowCursor():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_WarpMouseGlobal():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_CaptureMouse():
    pass

@pytest.mark.skip("not implemented")
def test_SDL_GetGlobalMouseState():
    pass
