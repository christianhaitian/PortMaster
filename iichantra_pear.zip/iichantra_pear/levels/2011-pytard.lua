CreateMap({
	{constants.ObjPlayer, "sohchan", -296, -253},
	{constants.ObjTile, "2011house3", -318, -325, 0, -0.900000},
	{constants.ObjGroup, "phys-empty", -366, -365, -303, 61},
	{constants.ObjGroup, "phys-empty", -359, 42, 329, 101},
	{constants.ObjGroup, "phys-empty", 308, -332, 363, 99},
	{constants.ObjGroup, "phys-empty", -375, -397, 396, -335},
	{constants.ObjGroup, "phys-empty-cl", -319, -95, -202, -75},
	{constants.ObjGroup, "phys-empty-cl", 204, -93, 323, -77},
})
