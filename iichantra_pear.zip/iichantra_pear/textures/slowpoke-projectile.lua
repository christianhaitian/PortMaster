count = 4
main = {
	{ x = 0, y = 0, w = 16, h = 16 },	-- frame 0
	{ x = 16, y = 0, w = 16, h = 16 },	-- frame 1
	{ x = 32, y = 0, w = 16, h = 16 },	-- frame 2
	{ x = 48, y = 0, w = 16, h = 16 }	-- frame 3
}
