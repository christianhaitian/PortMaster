count = 7
main = {
	{ x = 0, y = 0, w = 64, h = 32 },		-- frame 0
	{ x = 64, y = 0, w = 64, h = 32 },		-- frame 1
	{ x = 128, y = 0, w = 64, h = 32 },		-- frame 2
	{ x = 192, y = 0, w = 64, h = 32 },		-- frame 3
	{ x = 0, y = 32, w = 64, h = 32 },		-- frame 4
	{ x = 64, y = 32, w = 64, h = 32 },		-- frame 5
	{ x = 128, y = 32, w = 64, h = 32 }		-- frame 6
}
