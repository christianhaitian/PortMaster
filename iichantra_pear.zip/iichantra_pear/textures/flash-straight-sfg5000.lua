count = 3
main = {
	{ x = 0, y = 0, w = 128, h = 32 },		-- frame 0
	{ x = 128, y = 0, w = 128, h = 32 },		-- frame 1
	{ x = 256, y = 0, w = 128, h = 32 }		-- frame 2
}
