count = 3
main = {
	{ x = 0, y = 0, w = 31, h = 80 },	-- frame 0
	{ x = 31, y = 0, w = 31, h = 80 },	-- frame 1
	{ x = 63, y = 0, w = 35, h = 80 }	-- frame 2
}
