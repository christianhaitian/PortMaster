count = 7
main = {
	{ x = 2, y = 4, w = 17, h = 7 },	-- frame 0
	{ x = 2, y = 15, w = 17, h = 7 },	-- frame 1
	{ x = 2, y = 26, w = 17, h = 7 },	-- frame 2
	{ x = 23, y = 3, w = 10, h = 10 },	-- frame 3
	{ x = 23, y = 14, w = 10, h = 10 },	-- frame 4
	{ x = 41, y = 4, w = 10, h = 10 },	-- frame 5
	{ x = 41, y = 15, w = 10, h = 10 }	-- frame 6
}
