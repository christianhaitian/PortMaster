count = 7
main = {
	{ x = 2, y = 4, w = 72, h = 104 },	-- frame 0
	{ x = 77, y = 4, w = 31, h = 17 },	-- frame 1
	{ x = 77, y = 23, w = 31, h = 17 },	-- frame 2
	{ x = 77, y = 42, w = 31, h = 17 },	-- frame 3
	{ x = 109, y = 2, w = 22, h = 84 },	-- frame 4
	{ x = 133, y = 0, w = 148, h = 66 },	-- frame 5
	{ x = 77, y = 60, w = 28, h = 29 }	-- frame 6
}
