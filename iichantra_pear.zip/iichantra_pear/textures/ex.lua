count = 4
main = {
	{ x = 6, y = 2, w = 84, h = 80 },	-- frame 0
	{ x = 92, y = 5, w = 89, h = 80 },	-- frame 1
	{ x = 181, y = 3, w = 82, h = 83 },	-- frame 2
	{ x = 276, y = 6, w = 50, h = 77 }	-- frame 3
}
