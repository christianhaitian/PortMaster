count = 4
main = {
	{ x = 2, y = 2, w = 12, h = 12 },	-- frame 0
	{ x = 18, y = 2, w = 12, h = 12 },	-- frame 1
	{ x = 34, y = 2, w = 12, h = 12 },	-- frame 2
	{ x = 50, y = 2, w = 12, h = 14 }	-- frame 3
}
