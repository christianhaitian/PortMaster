count = 5
main = {
	{ x = 0, y = 0, w = 35, h = 153 },	-- frame 0
	{ x = 35, y = 0, w = 35, h = 153 },	-- frame 1
	{ x = 70, y = 0, w = 35, h = 153 },	-- frame 2
	{ x = 105, y = 108, w = 35, h = 45 },	-- frame 3
	{ x = 105, y = 63, w = 12, h = 45 }	-- frame 4
}
