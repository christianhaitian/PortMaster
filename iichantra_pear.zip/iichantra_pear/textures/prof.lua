count = 12
main = {
	{ x = 6, y = 4, w = 28, h = 71 },	-- frame 0
	{ x = 36, y = 8, w = 28, h = 67 },	-- frame 1
	{ x = 66, y = 8, w = 28, h = 67 },	-- frame 2
	{ x = 95, y = 8, w = 29, h = 67 },	-- frame 3
	{ x = 128, y = 7, w = 33, h = 68 },	-- frame 4
	{ x = 163, y = 6, w = 38, h = 69 },	-- frame 5
	{ x = 3, y = 78, w = 48, h = 69 },	-- frame 6
	{ x = 56, y = 78, w = 39, h = 69 },	-- frame 7
	{ x = 98, y = 80, w = 32, h = 67 },	-- frame 8
	{ x = 135, y = 79, w = 39, h = 68 },	-- frame 9
	{ x = 181, y = 78, w = 47, h = 69 },	-- frame 10
	{ x = 0, y = 149, w = 35, h = 69 }	-- frame 11
}
