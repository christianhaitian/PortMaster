count = 4
main = {
	{ x = 7, y = 4, w = 114, h = 81 },	-- frame 0
	{ x = 128, y = 4, w = 114, h = 81 },	-- frame 1
	{ x = 9, y = 96, w = 114, h = 81 },	-- frame 2
	{ x = 20, y = 198, w = 101, h = 42 }	-- frame 3
}
