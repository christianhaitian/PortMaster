count = 1
main = {
	{ x = 0, y = 0, w = 54, h = 480 }	-- frame 0
}
