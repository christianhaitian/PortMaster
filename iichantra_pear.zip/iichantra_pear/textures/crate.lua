count = 4
main = {
	{ x = 0, y = 0, w = 89, h = 89 },	-- frame 0
	{ x = 89, y = 0, w = 89, h = 89 },	-- frame 1
	{ x = 0, y = 89, w = 89, h = 89 },	-- frame 2
	{ x = 89, y = 89, w = 89, h = 89 }	-- frame 3
}
