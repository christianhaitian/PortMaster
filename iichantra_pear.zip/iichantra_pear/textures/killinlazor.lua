count = 2
main = {
	{ x = 0, y = 0, w = 358, h = 12 },	-- frame 0
	{ x = 0, y = 12, w = 358, h = 12 }	-- frame 1
}
