count = 4
main = {
	{ x = 3, y = 4, w = 45, h = 45 },	-- frame 0
	{ x = 3, y = 51, w = 45, h = 45 },	-- frame 1
	{ x = 52, y = 52, w = 45, h = 45 },	-- frame 2
	{ x = 52, y = 4, w = 45, h = 45 }	-- frame 3
}
