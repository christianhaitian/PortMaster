count = 10
main = {
	{ x = 0, y = 0, w = 89, h = 54 },	-- frame 0
	{ x = 0, y = 60, w = 89, h = 54 },	-- frame 1
	{ x = 0, y = 127, w = 90, h = 54 },	-- frame 2
	{ x = 114, y = 0, w = 92, h = 55 },	-- frame 3
	{ x = 114, y = 55, w = 101, h = 56 },	-- frame 4
	{ x = 114, y = 118, w = 119, h = 75 },	-- frame 5
	{ x = 233, y = 6, w = 58, h = 15 },	-- frame 6
	{ x = 233, y = 25, w = 58, h = 15 },	-- frame 7
	{ x = 236, y = 62, w = 16, h = 16 },	-- frame 8
	{ x = 254, y = 62, w = 16, h = 16 },	-- frame 9
}
