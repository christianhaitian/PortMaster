count = 1
main = {
	{ x = 0, y = 0, w = 100, h = 100 },	-- frame 0
}
