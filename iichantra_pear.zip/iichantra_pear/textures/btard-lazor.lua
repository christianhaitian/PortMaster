count = 4
main = {
	{ x = 0, y = 1, w = 32, h = 1 },	-- frame 0
	{ x = 0, y = 3, w = 32, h = 3 },	-- frame 1
	{ x = 0, y = 7, w = 32, h = 5 },	-- frame 2
	{ x = 0, y = 13, w = 32, h = 7 }	-- frame 3
}
