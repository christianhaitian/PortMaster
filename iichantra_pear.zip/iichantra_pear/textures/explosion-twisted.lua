count = 5
main = {
	{ x = 6, y = 7, w = 27, h = 25 },	-- frame 0
	{ x = 43, y = 2, w = 44, h = 38 },	-- frame 1
	{ x = 95, y = 2, w = 63, h = 54 },	-- frame 2
	{ x = 8, y = 49, w = 64, h = 60 },	-- frame 3
	{ x = 88, y = 71, w = 61, h = 54 }	-- frame 4
}
