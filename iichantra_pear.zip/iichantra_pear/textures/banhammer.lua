count = 8
main = {
	{ x = 0, y = 0, w = 40, h = 80 },	-- frame 0
	{ x = 40, y = 0, w = 40, h = 80 },	-- frame 1
	{ x = 80, y = 0, w = 40, h = 80 },	-- frame 2
	{ x = 120, y = 0, w = 40, h = 80 },	-- frame 3
	{ x = 160, y = 0, w = 40, h = 80 },	-- frame 4
	{ x = 200, y = 0, w = 40, h = 80 },	-- frame 5
	{ x = 240, y = 0, w = 40, h = 80 },	-- frame 6
	{ x = 280, y = 0, w = 40, h = 80 }	-- frame 7
}
