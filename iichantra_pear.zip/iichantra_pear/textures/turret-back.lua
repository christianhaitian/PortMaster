count = 3
main = {
	{ x = 0, y = 0, w = 45, h = 43 },	-- frame 0
	{ x = 45, y = 0, w = 54, h = 43 },	-- frame 1
	{ x = 1, y = 45, w = 43, h = 43 }	-- frame 2
}
