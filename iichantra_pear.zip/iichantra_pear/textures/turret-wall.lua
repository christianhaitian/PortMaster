count = 10
main = {
	{ x = 0, y = 0, w = 36, h = 32 },	-- frame 0
	{ x = 38, y = 0, w = 36, h = 32 },	-- frame 1
	{ x = 79, y = 0, w = 36, h = 32 },	-- frame 2
	{ x = 118, y = 1, w = 36, h = 32 },	-- frame 3
	{ x = 156, y = 1, w = 48, h = 32 },	-- frame 4
	{ x = 4, y = 34, w = 50, h = 32 },	-- frame 5
	{ x = 209, y = 2, w = 36, h = 32 },	-- frame 6
	{ x = 58, y = 34, w = 36, h = 32 },	-- frame 7
	{ x = 98, y = 34, w = 36, h = 32 },	-- frame 8
	{ x = 138, y = 34, w = 36, h = 32 }	-- frame 9
}
