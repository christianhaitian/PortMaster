count = 7
main = {
	{ x = 8, y = 9, w = 5, h = 5 },	-- frame 0
	{ x = 19, y = 7, w = 9, h = 9 },	-- frame 1
	{ x = 32, y = 6, w = 11, h = 11 },	-- frame 2
	{ x = 0, y = 18, w = 23, h = 23 },	-- frame 3
	{ x = 27, y = 21, w = 61, h = 61 },	-- frame 4
	{ x = 94, y = 27, w = 53, h = 53 },	-- frame 5
	{ x = 154, y = 28, w = 53, h = 53 }	-- frame 6
}
