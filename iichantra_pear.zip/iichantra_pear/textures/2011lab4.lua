count = 5
main = {
	{ x = 3, y = 3, w = 65, h = 104 },	-- frame 0
	{ x = 70, y = 4, w = 65, h = 104 },	-- frame 1
	{ x = 3, y = 108, w = 65, h = 104 },	-- frame 2
	{ x = 136, y = 3, w = 40, h = 40 },	-- frame 3
	{ x = 136, y = 44, w = 19, h = 10 }	-- frame 4
}
