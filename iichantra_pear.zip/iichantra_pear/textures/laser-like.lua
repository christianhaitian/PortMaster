count = 5
main = {
	{ x = 0, y = 0, w = 32, h = 8 },		-- frame 0
	{ x = 0, y = 8, w = 32, h = 8 },		-- frame 1
	{ x = 0, y = 16, w = 32, h = 8 },		-- frame 2
	{ x = 0, y = 24, w = 32, h = 8 },		-- frame 3
	{ x = 0, y = 32, w = 32, h = 8 }		-- frame 4
}
