count = 3
main = {
	{ x = 0, y = 0, w = 32, h = 32 },	-- frame 0
	{ x = 32, y = 0, w = 32, h = 32 },	-- frame 1
	{ x = 0, y = 32, w = 32, h = 32 }	-- frame 2
}
