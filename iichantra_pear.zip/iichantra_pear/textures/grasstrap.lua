count = 5
main = {
	{ x = 0, y = 0, w = 128, h = 1 },	-- frame 0
	{ x = 0, y = 3, w = 128, h = 21 },	-- frame 1
	{ x = 0, y = 29, w = 128, h = 58 },	-- frame 2
	{ x = 0, y = 99, w = 128, h = 51 },	-- frame 3
	{ x = 0, y = 166, w = 128, h = 27 }	-- frame 4
}
