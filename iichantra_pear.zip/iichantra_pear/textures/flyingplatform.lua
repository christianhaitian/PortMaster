count = 3
main = {
	{ x = 4, y = 4, w = 99, h = 56 },	-- frame 0
	{ x = 104, y = 4, w = 99, h = 56 },	-- frame 1
	{ x = 7, y = 67, w = 99, h = 56 }	-- frame 2
}
