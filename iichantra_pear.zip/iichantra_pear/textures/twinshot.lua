count = 16
main = {
	{ x = 3, y = 3, w = 41, h = 5 },	-- frame 0
	{ x = 3, y = 11, w = 29, h = 31 },	-- frame 1
	{ x = 37, y = 10, w = 30, h = 31 },	-- frame 2
	{ x = 73, y = 5, w = 35, h = 24 },	-- frame 3
	{ x = 5, y = 47, w = 33, h = 43 },	-- frame 4
	{ x = 44, y = 44, w = 37, h = 48 },	-- frame 5
	{ x = 83, y = 34, w = 31, h = 31 },	-- frame 6
	{ x = 85, y = 69, w = 39, h = 42 },	-- frame 7
	{ x = 9, y = 99, w = 52, h = 55 },	-- frame 8
	{ x = 69, y = 159, w = 31, h = 32 },	-- frame 9
	{ x = 71, y = 113, w = 39, h = 43 },	-- frame 10
	{ x = 6, y = 161, w = 53, h = 55 },	-- frame 11
	{ x = 9, y = 228, w = 6, h = 6 },	-- frame 12
	{ x = 21, y = 222, w = 16, h = 16 },	-- frame 13
	{ x = 41, y = 222, w = 16, h = 16 },	-- frame 14
	{ x = 60, y = 221, w = 18, h = 18 }	-- frame 15
}
