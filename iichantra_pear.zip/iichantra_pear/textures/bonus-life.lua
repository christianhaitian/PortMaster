count = 3
main = {
	{ x = 0, y = 0, w = 11, h = 12 },	-- frame 0
	{ x = 13, y = 0, w = 12, h = 12 },	-- frame 1
	{ x = 28, y = 0, w = 13, h = 12 }	-- frame 2
}
