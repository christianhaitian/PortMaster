--forbidden
parent = "enemies/superbtard"
offscreen_distance = 640
offscreen_behavior = constants.offscreenDestroy


