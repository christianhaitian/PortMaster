--forbidden

parent = "enemies/slowpoke"
offscreen_distance = 640
offscreen_behavior = constants.offscreenDestroy

