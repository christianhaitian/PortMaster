--forbidden
parent = "enemies/btard-ambush"

offscreen_distance = 640
offscreen_behavior = constants.offscreenDestroy

