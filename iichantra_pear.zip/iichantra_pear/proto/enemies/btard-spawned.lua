--forbidden
parent = "enemies/btard"

offscreen_distance = 640
offscreen_behavior = constants.offscreenDestroy

