parent = "enemies/slowpoke-moonwalking"
offscreen_distance = 640
offscreen_behavior = constants.offscreenDestroy

