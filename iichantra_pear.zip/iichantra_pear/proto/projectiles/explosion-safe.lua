--forbidden
parent = "projectiles/explosion";
bullet_damage = 0;
push_force = 0;