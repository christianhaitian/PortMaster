name = "lab-door1";
texture = "lab-door1";
FunctionName = "CreateSprite";

z = -0.7;

physic = 0;
phys_solid = 0;
phys_one_sided = 0;
phys_bullet_collidable = 0;