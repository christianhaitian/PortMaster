texture = "2011cave";

z = -0.91;

animations =
{
	{
		name = "idle";
		frames =
		{
			{ num = 4 }		
		}
	}
}
