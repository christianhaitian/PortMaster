texture = "crate";

z = -0.8997;
