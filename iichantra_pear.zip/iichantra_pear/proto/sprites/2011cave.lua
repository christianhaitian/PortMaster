texture = "2011cave";

z = -0.9;
