texture = "2011lab4";

z = -0.8997;
