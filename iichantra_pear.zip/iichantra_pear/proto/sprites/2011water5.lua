texture = "2011tiles2";

z = -0.99;

animations =
{
	{
		name = "idle";
		frames =
		{
			{ dur = 100; num = 13 },
			{ dur = 100; num = 14 },
			{ dur = 100; num = 15 },
			{ dur = 100; num = 16 },
			{ com = constants.AnimComLoop }
		}
	}
}
