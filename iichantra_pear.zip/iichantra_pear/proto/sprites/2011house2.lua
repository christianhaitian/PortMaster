texture = "house2";

z = -0.9;
