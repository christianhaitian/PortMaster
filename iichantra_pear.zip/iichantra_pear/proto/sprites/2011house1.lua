texture = "house1";

z = -0.9;
