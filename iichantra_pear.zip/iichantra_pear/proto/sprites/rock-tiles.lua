texture = "rock_tiles";

z = -0.9;
