texture = "2011tiles2";

z = -0.99;

animations =
{
	{
		name = "idle";
		frames =
		{
			{ dur = 100; num = 17 },
			{ dur = 100; num = 18 },
			{ dur = 100; num = 19 },
			{ dur = 100; num = 18 },
			{ com = constants.AnimComLoop }
		}
	}
}
