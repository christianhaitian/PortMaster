--forbidden
name = "pteleport";
texture = "pteleport";
--FunctionName = "CreateSprite";

z = 1;

start_color = { 1.0, 1.0, 1.0, 1.0 };
var_color = { 0.2, 0.0, 0.0, 0.0 };
end_color = { 0.3, 1.0, 1.0, 1.0 };


max_particles = 100;
particle_life_min = 10;
particle_life_max = 30;

start_size = 4.0;
size_variability = 3.0;
end_size = 2.0;

particle_life = 5;
particle_life_var = 2;

system_life = 5;
emission = 10;