name = "default_environment";
material = 0;

walk_vel_multiplier = 0.5;
jump_vel_multiplier = 1;
bounce_bonus = 0;

gravity_bonus_x = 0;
gravity_bonus_y = 0;

script_on_enter = "enter_splash";
script_on_leave = "exit_splash"

sprites =
{
}

sounds =
{
}