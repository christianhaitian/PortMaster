--forbidden
name = "logo-cold";
texture = "logo-2011";
FunctionName = "CreateSprite";

z = 0.5;
image_width = 512;
image_height = 256;
frame_width = 512;
frame_height = 256;
frames_count = 0;
