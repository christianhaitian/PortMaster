--forbidden
texture = "TheEnd2011";

z = 0;