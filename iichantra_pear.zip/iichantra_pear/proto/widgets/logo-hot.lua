--forbidden
name = "logo-hot";
texture = "logo-hot";
FunctionName = "CreateSprite";

z = 1;
image_width = 512;
image_height = 256;
frame_width = 512;
frame_height = 256;
frames_count = 0;
