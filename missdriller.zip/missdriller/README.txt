Miss Driller

https://github.com/jbanes/rs97-mrdrillux

The original game idea is from Namco's Mr. Driller. http://en.wikipedia.org/wiki/Mr._Driller

The remake in SDL is Miss Driller by Adas. Its original Japanese README file is preserved as "missdriller-readme.txt". http://www.geocities.co.jp/berkeley/2093/driller.html

The initial handheld port is Drill2x by kfazz, birslip and edd. This introduced the low-res graphics set. http://wiki.gp2x.org/wiki/Drill2x



CONTROLS

Gameplay
A = Enter

Highscore Entry
B - Scrub
Start - Submit