#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

chmod 666 /dev/tty1

if [[ -e "/usr/share/plymouth/themes/text.plymouth" ]]; then
    plymouth="/usr/share/plymouth/themes/text.plymouth"
    temp=$(grep "title=" $plymouth)
fi

if [[ $temp == *"ArkOS"* ]]; then
  cp /home/ark/.asoundrcfords /home/ark/.asoundrc
fi

rm -rf ~/.config/opentyrian
ln -sfv /$directory/ports/opentyrian/ ~/.config/
cd /$directory/ports/opentyrian
$controlfolder/oga_controls opentyrian $param_device &
/$directory/ports/opentyrian/opentyrian --data=/$directory/ports/opentyrian/data

if [[ $temp == *"ArkOS"* ]]; then
  cp /home/ark/.asoundrcbak /home/ark/.asoundrc
fi

kill -9 $(pidof oga_controls)
systemctl restart oga_events &
printf "\033c" >> /dev/tty1
