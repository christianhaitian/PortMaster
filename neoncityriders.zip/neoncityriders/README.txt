Neon City Riders
https://store.steampowered.com/app/1102650/Neon_City_Riders/
"Explore a decaying futuristic city in search of items, superpowers and companions to free all the turfs of the evil gangs and unite their people again!"

Controls:
dpad/L stick= movement
x = attack
y = interact
a/b= use powers (unlocked in game)

ported by mattyj513
