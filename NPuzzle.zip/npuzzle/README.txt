NPuzzle

NPuzzle ius a 15 puzzle style sliding game where you have to rearrange the tiles in order.


Developer: Andy Shih (https://github.com/ashih42)
URL: https://github.com/ashih42/n_puzzle

Images from : https://labs.openai.com/


CONTROLS
========

Start + Select = Exit
Select = Exit
Start = Cycle images
A = Cycle images
B = Undo
Y = Toggle hints
X = Reset puzzle