Magic Vigilante
https://nizakashii.itch.io/magicvigilante
"This is a difficult bullet-hell shooter. There are 7+1 levels. Half of them are boss battles. Good luck!"

Controls: 
dpad = movement
l2 = slows time
r/x/a/b = shoot

ported by mattyj513