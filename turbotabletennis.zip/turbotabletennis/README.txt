TurboTableTennis

https://menacingmecha.itch.io/turbo-table-tennis
"Ping pong return challenge"

Controls: 
dpad up = serve
dpad l/r = movement


ported by mattyj513