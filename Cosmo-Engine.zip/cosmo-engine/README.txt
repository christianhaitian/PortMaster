Cosmo Engine

A new game engine to play the MS-DOS game "Cosmo's Cosmic Adventure" on modern systems

URL: https://github.com/yuv422/cosmo-engine

The first episode is shareware and included. You can add episode 2 & 3 (STN,VOL, and CFG files) to the data folder.


CONTROLS
========

Start Button = Menu

A Button = Jump/Select
B Button = Bomb/Cancel

Left = Move Left
Right = Move right
Up = Look Up
Down = Look Down




