OpenSyobon-M
------------------
by Wei Mingzhi <whistler_wmz@users.sf.net>

https://github.com/weimzh/syobon



The original website of Syobon Action is at:
http://web.archive.org/web/20071228195123/http://www.geocities.jp/z_gundam_tanosii/home/Main.html

This version contains additional levels made by Kazuki Okawa:
http://yaruki0.sakura.ne.jp/programs/action.html

This version is based on Open Syobon Action RC 2 by Mathew Velasquez:
http://sourceforge.net/projects/opensyobon/

Requires:
SDL2, SDL2_mixer

Controls:
A/B/X/Y - Jump
Left, Right - Movement
Down - Enter warp pipe
Start - Enter
