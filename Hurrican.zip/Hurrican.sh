#!/bin/bash

DATA="https://github.com/drfiemost/Hurrican/archive/refs/heads/master.zip"

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

CONFIGFOLDER="/$directory/ports/hurrican"
DATAFOLDER="$CONFIGFOLDER/data"

WGET="wget"

if [ -f "/storage/.config/.OS_ARCH" ]; then
  WGET="$CONFIGFOLDER/wget"
  export LD_LIBRARY_PATH="$LD_LIBRARY_PATH:/$CONFIGFOLDER/libs"
fi

$ESUDO chmod 666 /dev/tty1
if [ ! -e "${DATAFOLDER}/levels/levellist.dat" ]; then
    clear > /dev/tty1
    cat /etc/motd > /dev/tty1
    echo "Downloading Hurrican data, please wait..." > /dev/tty1
    rm -rf "${DATAFOLDER}"
    rm -rf "${CONFIGFOLDER}/lang"
    $WGET "${DATA}" -q --show-progress > /dev/tty1 2>&1
    echo "Installing Hurrican data, please wait..." > /dev/tty1
    $ESUDO unzip "master.zip" "Hurrican-master/Hurrican/data/*" -d "${CONFIGFOLDER}"
    $ESUDO unzip "master.zip" "Hurrican-master/Hurrican/lang/*.lng" -d "${CONFIGFOLDER}"
    mv "${CONFIGFOLDER}/Hurrican-master/Hurrican/data" "${CONFIGFOLDER}"
    mv "${CONFIGFOLDER}/Hurrican-master/Hurrican/lang" "${CONFIGFOLDER}"
    rm -rf "${CONFIGFOLDER}/Hurrican-master" > /dev/tty1 2>&1
    rm "master.zip" > /dev/tty1 2>&1
fi

cd "${CONFIGFOLDER}"
$ESUDO rm -rf ~/.config/hurrican
ln -sfv ${CONFIGFOLDER}/conf/hurrican/ ~/.config/
$ESUDO rm -rf ~/.local/share/hurrican
ln -sfv ${CONFIGFOLDER}/highscores/hurrican/ ~/.local/share/

$ESUDO chmod 666 /dev/uinput
$GPTOKEYB "hurrican" -c "./hurrican.gptk" &
SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./hurrican --depth 16 2>&1 | tee $CONFIGFOLDER/log.txt
$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1