# Rise of the Triad Launch Arguments

AIM        - Give Aim Crosshair

FULLSCREEN - Start in fullscreen mode

WINDOW     - Start in windowed mode

RESOLUTION - Specify the screen resolution to use (next param is <widthxheight>)

FILERTL    - used to load Userlevels (RTL files)
 (next parameter is RTL filename)

FILERTC    - used to load Battlelevels (RTC files)		(next parameter is RTC filename)

FILE       - used to load Extern WAD files
(next parameter is WAD filename)

NOJOYS     - Disable check for joystick

NOMOUSE    - Disable check for mouse

VER        - Version number

MAPSTATS   - Dump Map statistics to ERROR

TILESTATS  - Dump Tile statistics to ERROR

MONO       - Enable mono-monitor support

SCREENSHOTS- Clean screen capture for shots

PAUSE      - Pauses startup screen information

ENABLEVR   - Enable VR helmet input devices

NOECHO     - Turn off sound reverb

DEMOEXIT   - Exit program when demo is terminated

WARP       - Warp to specific ROTT level (next parameter is level to start on)

TIMELIMIT  - Play ROTT in time limit mode
(next parameter is time in seconds)

MAXTIMELIMIT - Maximimum time to count down from		(next parameter is time in seconds)

DOPEFISH   - I think you know
