#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
source $controlfolder/swap_file.txt

get_controls
create_swap_file

$ESUDO chmod 666 /dev/tty1

GAMEDIR="/$directory/ports/rott"

ROTTBIN="rott_sw"
if [ -f "$GAMEDIR/DARKWAR.WAD" ]; then
  ROTTBIN="rott"
fi

cd $GAMEDIR

$ESUDO rm -rf ~/.rott
$ESUDO ln -sfv $GAMEDIR/conf/.rott ~/

$ESUDO $controlfolder/oga_controls $ROTTBIN $param_device &
SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./$ROTTBIN 2>&1 | tee $GAMEDIR/log.txt
$ESUDO kill -9 $(pidof oga_controls)
$ESUDO systemctl restart oga_events &

delete_swap_file
printf "\033c" >> /dev/tty1
