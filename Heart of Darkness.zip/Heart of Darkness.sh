#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

chmod 666 /dev/tty1

cd /$directory/ports/hode
$controlfolder/oga_controls hode $param_device &
SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./hode --datapath="/$directory/ports/hode/gamedata"  --savepath="/$directory/ports/hode/savedata" 2>&1 | tee -a ./log.txt
kill -9 $(pidof oga_controls)
systemctl restart oga_events &