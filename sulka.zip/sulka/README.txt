Sulka
https://kultisti.itch.io/sulka
"A simple platformer. Help Sulka find a new home."

Controls: 
dpad/L stick = movement
a/b = jump

Notes: Special thanks to Kultisti at https://kultisti.itch.io/ for creating the game and allowing us to distribute.

ported by mattyj513