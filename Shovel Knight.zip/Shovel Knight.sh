#!/bin/bash


if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

$ESUDO chmod 666 /dev/tty1

cd /$directory/ports/shovelknight/gamedata/shovelknight/32

export LIBGL_NOBANNER=1
export LIBGL_ES=2
export LIBGL_GL=21
export LIBGL_FB=4
export BOX86_LOG=0
export LD_LIBRARY_PATH=/$directory/ports/shovelknight/box86/lib:/$directory/ports/shovelknight/box86/native:/usr/lib:/usr/lib32
export BOX86_LD_LIBRARY_PATH=/$directory/ports/shovelknight/box86/lib:/$directory/ports/shovelknight/box86/native:/usr/lib32/:./:lib/:lib32/:x86/
export BOX86_DYNAREC=1
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

if [ ! -f "/$directory/ports/shovelknight/gamedata/shovelknight/32/oga_controls" ]; then
  cp -f /$directory/ports/shovelknight/oga_controls* .
fi
$ESUDO rm -rf ~/.local/share/Yacht\ Club\ Games
$ESUDO ln -s /$directory/ports/shovelknight/Yacht\ Club\ Games ~/.local/share/
$ESUDO ./oga_controls box86 $param_device &
/$directory/ports/shovelknight/box86/box86 ShovelKnight
$ESUDO kill -9 $(pidof oga_controls)
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1