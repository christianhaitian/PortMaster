New Port for Dome Romantik

URL:  https://bippinbits.itch.io/dome-romantik

Dome Romantik

Instructions: Dome Romantik files are already included and ready to go. To Force a particular version rename the desired one in the installation folder as domeromantik-linux.zip(same with gptk file) and delete the others ones, then boot

Notes: A heartfelt thank you goes out to René from Bippinbits for granting authorization for this port and its distribution. And obviously a big thanks at the portmaster team for testing it.


Tested on Rg353,rg351v and Rg552 on Arkos. Jelos and Amberelec