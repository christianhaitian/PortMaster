
## Notes

Thanks to Harley Wilson at https://hwilson.itch.io/bot-break for creating the game and allowing us to distribute the files.

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick/l1/l2/r1/r2| movement |
| down/a| power shot (hold/release) |