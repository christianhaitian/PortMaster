F1 Race

F1 Race is a port of the simple race game from MTK OS to SDL2 and Emscripten.

New car by tekkenfede

Developer: EXL (https://github.com/EXL)
URL: https://github.com/EXL/F1-Race


CONTROLS
========
Select = Esc/Exit
Start + Select = Exit

Dpad and left stick = movement

A = Jump/Fly
X = Switch MIDI
Y = Toggle mute


