Nonny

Nonny lets you play and create nonogram puzzles! Nonograms (also known as Griddlers, Picross, and Paint-by-Number) are logic puzzles played on a grid of squares.
 The squares are filled in or left blank according to numeric clues at the sides of the grid. When the puzzle is finished, the filled-in squares form a picture.

Developer: Greg Kikola (https://github.com/gkikola)
URL: https://github.com/gkikola/nonny


CONTROLS
========

File Menu

Dpad nd and Left stick up/down = up and down
Dpad and Left stick left/right = move through navigation breadcrums
B = up one directory
Y = Home directory
A = Select file
X = Open saved

Puzzle Screen

Dpad and left stick = move selector
A = Select/Unselect
B = Mark X
Y = Toggle hints
X = Analyze and solve
L1/R1 = Zoom out/in
L2/R2 = cycle colors
Right stick = Move puzzle