function love.conf(t)
    t.identity = "nova-pinball"
    t.version = "11.2"
    t.console = false
    t.window.title = "Nova Pinball Table Editor"
    t.window.width = 1000
end
