# Love Frames

## Information

Love Frames is a GUI library for [LÖVE](https://love2d.org/).

## License

Love Frames is licensed under the zlib/libpng license. For more information, please read license.txt.

## Credits

Created by Kenny Shields

## Third-Party Libraries

middleclass - https://github.com/kikito/middleclass

utf8.lua - https://github.com/Stepets/utf8.lua


tween.lua - https://github.com/kikito/tween.lua (Demo)

## History

[Changelog](https://github.com/linux-man/LoveFrames/blob/master/loveframes/changelog.txt)

