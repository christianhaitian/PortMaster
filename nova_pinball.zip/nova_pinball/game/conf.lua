function love.conf (t)
    t.identity = "nova-pinball"
    t.window.title = "Pinball"
    t.window.width = 640
    t.window.height = 480
    t.version = "11.2"
end

