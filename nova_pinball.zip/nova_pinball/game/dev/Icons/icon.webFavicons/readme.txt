1. Copy the "qicons" directory into the root location of the web site
2. Copy "browserconfig.xml", "favicon.ico" and "apple-touch-icon.png" into the root location of the web site
3. Add the folowing lines into the HEAD-section of your HTML page:

<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/qicons/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
<link rel="icon" type="image/png" sizes="16x16" href="/qicons/favicon-16x16.png">
<link rel="icon" type="image/png" sizes="32x32" href="/qicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="48x48" href="/qicons/favicon-48x48.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/qicons/android-icon-192x192.png">
<link rel="apple-touch-icon" href="/qicons/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="76x76" href="/qicons/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="120x120" href="/qicons/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="152x152" href="/qicons/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/qicons/apple-icon-180x180.png">
<link rel="apple-touch-icon-precomposed" href="/qicons/apple-icon-60x60.png">
<link rel="apple-touch-icon-precomposed" sizes="76x76" href="/qicons/apple-icon-76x76.png">
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="/qicons/apple-icon-120x120.png">
<link rel="apple-touch-icon-precomposed" sizes="152x152" href="/qicons/apple-icon-152x152.png">
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="/qicons/apple-icon-180x180.png">
<link rel="manifest" href="/qicons/manifest.json">
