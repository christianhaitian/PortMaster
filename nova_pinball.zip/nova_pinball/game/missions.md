
Goal: Make the star go supernova

Missions:

Evolve into a red giant
+ Complete the "NOVA" word bonus
The star turns red

Activate hydrogen release
+ Shoot both ramps

Start fusion stage 1
+ Hit the left targets
+ Shoot for the left ramp
Slowly scale out the first wheel

Start fusion stage 2
+ Hit the right targets
+ Shoot for the right ramp
Slowly scale out the second wheel

Fusion in progress
1 minute countdown to next event

Fusion unstable
1 minute countdown to next event
Slowly scale out the light rays

Collapse the star
+ Hit both ramps
+ Complete the "NOVA" word bonus
Fade in the black hole (the hole lock is now in effect)

Wormhole
+ Lock the ball in the black hole x3
Open a worm-hole that swallows the black hole.
The hole disappears, the planet is returned.
Reset
