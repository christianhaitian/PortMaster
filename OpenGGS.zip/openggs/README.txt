OpenGGS

A Free Software/Open Source implementation/remake of "The Great Giana Sisters".


Developer: Martin Imobersteg and Roman Högg
URL: https://github.com/bugix/OpenGGS


CONTROLS
========

Start = Pause/Enter
Select = Back/Esc
Start + Select = Exit

Dpad and left stick = move left/right

A = Jump
B = Shoot

