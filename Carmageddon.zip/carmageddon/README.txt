Copy here Carmageddon files.
You can also use the demo version, available at: https://rr2000.cwaboard.co.uk/R4/PC/carmdemo.zip
