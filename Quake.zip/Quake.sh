#!/bin/bash

ldpath=""
whichos=$(grep "title=" "/usr/share/plymouth/themes/text.plymouth")
if [[ $whichos == *"TheRA"* ]]; then
  raloc="/opt/retroarch/bin"
elif [[ -e "/storage/.config/.OS_ARCH" ]]; then
  raloc="/usr/bin"
  ldpath="LD_LIBRARY_PATH=/usr/lib32"
else
  raloc="/usr/local/bin"
fi

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  GAMEDIR="/roms2/ports/quake"
else
  GAMEDIR="/roms/ports/quake"
fi

$ldpath $raloc/retroarch32 -L $GAMEDIR/tyrquake_libretro.so $GAMEDIR/quakepaks/