
## Notes

Thanks to Harley Wilson at https://hwilson.itch.io for creating the game and allowing us to distribute the game files

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement  |
| a/b| shoot|
| select| pause |
