SDL Sopwith

SDL Sopwith is a port of the game Sopwith, which was originally by BMB CompuScience Canada.


Developer: Simon Howard (https://github.com/fragglet)
URL: https://github.com/fragglet/sdl-sopwith



CONTROLS
========

Up/Down - Pull up/down
Left - Decelerate
Right - Accelerate
A - Fire machine gun
B - Drop bomb
X - Flip plane
Y - Return to base
Back - Qui