#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

$ESUDO chmod 666 /dev/tty0
$ESUDO chmod 666 /dev/tty1
$ESUDO chmod 666 /dev/uinput

export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

GAMEDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/ecwolfsu"


if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
      param_device="anbernic"
      hotkey="Select"
      HEIGHT="15"
      WIDTH="55"
      ECWOLF_CONFIG="ecwolf_480x320.cfg"
      if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ] || [ -f "/opt/system/Advanced/Switch to SD2 for Roms.sh" ] || [ -f "/boot/rk3326-rg351v-linux.dtb" ]; then
        param_device="anbernic"
        hotkey="Select"
        HEIGHT="20"
        WIDTH="60"
        ECWOLF_CONFIG="ecwolf_640x480.cfg"
      fi
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      param_device="oga"
      hotkey="Minus"
      HEIGHT="15"
      WIDTH="55"
      ECWOLF_CONFIG="ecwolf_480x320.cfg"
	else
      param_device="rk2020"
      hotkey="Select"
      HEIGHT="15"
      WIDTH="55"
      ECWOLF_CONFIG="ecwolf_480x320.cfg"
   fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
      param_device="ogs"
      hotkey="Select"
      HEIGHT="20"
      WIDTH="60"
      ECWOLF_CONFIG="ecwolf_640x480.cfg"
elif [[ -e "/dev/input/by-path/platform-gameforce-gamepad-event-joystick" ]]; then
      param_device="chi"
      hotkey="1"
      HEIGHT="20"
      WIDTH="60"
      ECWOLF_CONFIG="ecwolf_640x480.cfg"
elif [[ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG552" ]]; then
      param_device="rg552"
      hotkey="L3"
      HEIGHT="20"
      WIDTH="60"
      ECWOLF_CONFIG="ecwolf_848x480.cfg"
elif [[ -e "/dev/input/by-path/platform-singleadc-joypad-event-joystick" ]]; then
      param_device="rg503"
      hotkey="Select"
      HEIGHT="20"
      WIDTH="60"
      ECWOLF_CONFIG="ecwolf_848x480.cfg"
else
      DEVICE="${1}"
      param_device="${2}"
      hotkey="Select"
      HEIGHT="20"
      WIDTH="60"
      ECWOLF_CONFIG="ecwolf_640x480.cfg"
fi


cd $GAMEDIR

export TERM=linux
export XDG_RUNTIME_DIR=/run/user/$UID/

# The 'printf "\033c" > /dev/tty0' below resets '/dev/tty0' for use (like running 'clear' in a linux terminal)
printf "\033c" > /dev/tty0
echo " " > /dev/tty0

$GPTOKEYB "dialog" -c "$GAMEDIR/dialog.gptk" &
dialog --clear

# dialog selection window
BACKTITLE="Wolfenstein 3D - Super Upgrades Menu"
TITLE="Super Upgrades"
MENU="Select a level set"
CHOICE_HEIGHT="15"

OPTIONS=(A  "A  - 17 Levels"
         B  "B  -  9 Levels"
         C  "C  - 60 Levels"
         D  "D  - 30 Levels"
         E  "E  - 30 Levels [!]"
         F  "F  - 10 Levels"
         G  "G  - 10 Levels"
         H  "H  - 10 Levels"
         I  "I  - 10 Levels"
         J  "J  - 30 Levels"
         K  "K  - 60 Levels"
         L  "L  - 31 Levels"
         M  "M  - 30 Levels"
         N  "N  - 18 Levels"
         O  "O  - 15 Levels"
         P  "P  - 10 Levels"
         Q  "Q  -  7 Levels"
         R  "R  - 10 Levels"
         S  "S  - 10 Levels"
         T  "T  - 10 Levels"
         U  "U  - 10 Levels"
         V  "V  - 10 Levels"
         W  "W  - 10 Levels"
         X  "X  - 10 Levels"
         Y  "Y  -  5 Levels"
         Z  "Z  - 10 Levels"
         AA "AA - 10 Levels"
         BB "BB - 10 Levels"
         CC "CC - 27 Levels"
         DD "DD - 10 Levels"
         EE "EE -  1 Level "
         FF "FF - 60 Levels"
         GG "GG - 60 Levels"
         HH "HH - 10 Levels"
         II "II - 60 Levels"
         JJ "JJ - 10 Levels"
         KK "KK - 10 Levels"
         LL "LL - 10 Levels"
         MM "MM - 20 Levels"
         NN "NN - 10 Levels"
         OO "OO -  1 Level "
         PP "PP - 10 Levels"
         QQ "QQ -  4 Levels"
         RR "RR -  4 Levels"
         SS "SS - 10 Levels"
         TT "TT -  1 Level "
         UU "UU -  1 Level "
         VV "VV -  4 Levels")

CHOICE=$(dialog --clear \
                --backtitle "$BACKTITLE" \
                --title "$TITLE" \
                --cancel-label "$hotkey + Start to Exit" \
                --menu "$MENU" \
                $HEIGHT $WIDTH $CHOICE_HEIGHT \
                "${OPTIONS[@]}" \
                2>&1 >/dev/tty0 )

clear
case $CHOICE in
        A)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'A'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/A/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        B)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'B'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/B/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        C)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'C'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/C/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        D)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'D'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/D/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        E)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'E'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/E/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        F)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'F'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/F/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        G)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'G'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/G/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        H)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'H'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/H/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        I)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'I'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/I/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        J)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'J'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/J/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        K)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'K'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/K/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        L)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'L'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/L/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        M)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'M'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/M/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        N)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'N'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/N/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        O)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'O'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/O/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        P)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'P'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/P/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        Q)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'Q'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/Q/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        R)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'R'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/R/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        S)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'S'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/S/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        T)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'T'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/T/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        U)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'U'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/U/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        V)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'V'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/V/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        W)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'W'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/W/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        X)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'X'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/X/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        Y)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'Y'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/Y/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        Z)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'Z'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/Z/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        AA)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'AA'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/AA/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        BB)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'BB'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/BB/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        CC)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'CC'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/CC/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        DD)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'DD'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/DD/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        EE)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'EE'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/EE/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        FF)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'FF'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/FF/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        GG)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'GG'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/GG/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        HH)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'HH'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/HH/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        II)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'II'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/II/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        JJ)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'JJ'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/JJ/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        KK)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'KK'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/KK/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        LL)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'LL'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/LL/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        MM)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'MM'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/MM/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        NN)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'NN'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/NN/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        OO)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'OO'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/OO/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        PP)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'PP'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/PP/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        QQ)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'QQ'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/QQ/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        RR)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'RR'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/RR/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        SS)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'SS'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/SS/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        TT)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'TT'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/TT/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        UU)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'UU'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/UU/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;
        VV)
            printf "\033c" > /dev/tty0
            echo " " > /dev/tty0
            echo "You chose levelset 'VV'" > /dev/tty0
            echo " " > /dev/tty0
            cp -f /$GAMEDIR/VV/* /$GAMEDIR/.
            sleep 3
            $ESUDO kill -9 $(pidof gptokeyb)
            cd "$GAMEDIR"
            ./ecwolf --config "./$ECWOLF_CONFIG" --data WL6
            ;;

esac

$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
pgrep -f ecwolf | sudo xargs kill -9
unset SDL_GAMECONTROLLERCONFIG
printf "\033c" >> /dev/tty1
