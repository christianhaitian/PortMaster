Quake III Arena Portmaster ReadMe
*Based on the work from: https://github.com/ec-/Quake3e
*This requires Portmaster to be installed to work: https://351elec.de/PortMaster
*To modify the controls either edit the autoconfig.cfg or delete it after first boot and update via the in game menu
*Add your Quake 3 product key by editing the file located in baseq3/q3key
*Place your pk3 files in baseq3/
	They should read as follows:
		baseq3/
			pak0.pk3
			pak1.pk3
			pak2.pk3
			pak3.pk3
			pak4.pk3
			pak5.pk3
			pak6.pk3
			pak7.pk3
			pak8.pk3 