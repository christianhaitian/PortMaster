#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

GAMEDIR=/$directory/ports/JediOutcast

cd $GAMEDIR

$ESUDO rm -rf ~/.local/share/openjo
ln -sfv /$directory/ports/JediOutcast/conf/openjo/ ~/.local/share/

export SDL_VIDEO_GL_DRIVER=./libs/libGL.so.1
export LIBGL_FB=4

source /etc/profile 
maxperf

$ESUDO chmod 666 /dev/uinput
$GPTOKEYB "openjo_sp.aarch64" -c "openjo_sp.aarch64.gptk" &
LD_LIBRARY_PATH=./libs:$LD_LIBRARY_PATH SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./openjo_sp.aarch64 2>&1 | tee ./log.txt
$ESUDO kill -9 $(pidof gptokeyb)
normperf
$ESUDO systemctl restart oga_events & 
printf "\033c" >> /dev/tty1