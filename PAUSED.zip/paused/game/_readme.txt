This project was merely a pastime of mine. It's not intended to
be professional by any means and its code may not be readable
or has the best design, but if you insist on poking around, you
are welcome to make your adjusting and/or add new levels, though I
wouldn't recommend it.

Take care.