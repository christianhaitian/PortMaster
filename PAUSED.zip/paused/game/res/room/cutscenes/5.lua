objects.story(
    10,
    58,
    {
        {'I\'m supposed ', 0.5},
        {'to write a', 0.4},
        {'\nstory, but ', 0.5},
        {'I\'m too lazy.', 1.6},
    }, 
    0.2, 
    'level/5'
)