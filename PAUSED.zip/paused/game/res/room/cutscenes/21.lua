objects.story(
    10,
    58,
    {
        {'...And they ', 0.4},
        {'lived happily ', 0.4},
        {'ever\nafter', 1.2},
        {', propably.', 1}
    }, 
    0.2, 
    'level/last'
)