objects.story(
    10,
    58,
    {
        {'There once were ', 0.5},
        {'a bunny\n', 0.4},
        {'and a duckling...', 1.6},
    }, 
    0.2, 
    'level/1'
)

