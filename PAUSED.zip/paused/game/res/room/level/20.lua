ldtk:level('level_20')
global.game.level.funcs['win'] = {
    function ()
        room.goTo('cutscenes/21')
    end,
}
