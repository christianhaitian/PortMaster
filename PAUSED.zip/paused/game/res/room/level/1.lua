ldtk:level('level_1')
objects.level_1_guide()