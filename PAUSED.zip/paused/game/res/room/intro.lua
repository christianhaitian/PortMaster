camera.setPosition(0, 0)
objects.logo()
ldtk:level('intro')
global.playMusic('let\'s-be-silly.mp3')