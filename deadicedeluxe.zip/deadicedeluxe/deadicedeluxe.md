
## Notes

Thanks to Harley Wilson at https://hwilson.itch.io/dead-ice-deluxe for creating the game and allowing us to distribute.

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement |
| a| strike/confirm |
| b| throw/cancel |
