NeverballPack is a NetRadiant/GtkRadiant 1.5 gamepack for Neverball.
To start mapping, copy the included files to your Radiant location.
