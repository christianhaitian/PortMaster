Neverball and Neverputt

Neverball

Tilt the floor to roll a ball through an obstacle course within the given time. If the ball falls or time expires, a ball is lost.
Collect coins to unlock the exit and earn extra balls. Red coins are worth 5. Blue coins are worth 10. A ball is awarded for 100 coins.

Neverputt

A hot-seat multiplayer miniature golf game, built on the physics and graphics engine of Neverball.

Developer: Neverball developers
URL: https://github.com/Neverball/neverball


CONTROLS
========

Neverball

Select = ESC
Start = Enter

Dpad and Left stick = movement
Right stick left/ right L/R = look

A = Select
B  Back/esc

Neverputt

Dpad and Left stick = ball direction and speed
A = Hit ball
B = ESC
Start = Enter
Select = ESC