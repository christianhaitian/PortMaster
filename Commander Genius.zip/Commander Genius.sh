#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

GAMEDIR="/$directory/ports/cgenius"

if [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
    $ESUDO sed -i '/width / s/480/857/' $GAMEDIR/cgenius.cfg
    $ESUDO sed -i '/height / s/320/480/' $GAMEDIR/cgenius.cfg
    $ESUDO sed -i '/gameHeight / s/200/240/' $GAMEDIR/cgenius.cfg
    $ESUDO sed -i '/aspect / s/0:0/4:3/' $GAMEDIR/cgenius.cfg
else
    $ESUDO sed -i '/width / s/857/480/' $GAMEDIR/cgenius.cfg
    $ESUDO sed -i '/height / s/480/320/' $GAMEDIR/cgenius.cfg
    $ESUDO sed -i '/gameHeight / s/240/200/' $GAMEDIR/cgenius.cfg
    $ESUDO sed -i '/aspect / s/4:3/0:0/' $GAMEDIR/cgenius.cfg
fi

$ESUDO chmod 666 /dev/tty1

$ESUDO rm -rf ~/.CommanderGenius
ln -sfv $GAMEDIR/.CommanderGenius/ ~/
cd $GAMEDIR
$ESUDO $controlfolder/oga_controls CGeniusExe $param_device &
./CGeniusExe 2>&1 | tee $GAMEDIR/log.txt
$ESUDO kill -9 $(pidof oga_controls)
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1
