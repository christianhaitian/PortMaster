# Exit to which level. 0 is always the world map in the galaxy games
def exitTo(fromLevel):
       if fromLevel == 17:
          to = 18
       else:
          to = 0
       return to


