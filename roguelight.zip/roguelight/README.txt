Roguelight
https://managore.itch.io/roguelight
"The deeper you travel the darker it gets,
and you only have your arrows to light the way."

Controls: 
dpad/L stick = movement
a = jump
x/r2 = hold to nock arrow, release to loose

ported by mattyj513