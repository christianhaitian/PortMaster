Beat2x

DDR style game by miq01 with artwork by Zenzuke

https://github.com/christopher-roelofs/beat2x

Controls
--------
Select + A - Quit to menu
A/B/X/Y - Select/Confirm




