Copy the following files here:
data
critter.dat
master.dat
patch000.dat

! DO NOT COPY fallout2.cfg, otherwise the resolution might be incorrect
