#!/bin/bash
# Ported by Maciej Suminski <orson at orson dot net dot pl>
# Built from https://github.com/alexbatalov/fallout2-ce

PORTNAME="Fallout 2"

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

cd /$directory/ports/fallout2

for f in data critter.dat master.dat patch000.dat; do
	if [[ ! -e "$f" ]]; then
		echo Missing file: $f > /dev/tty1
		sleep 5
		printf "\033c" >> /dev/tty1
		exit 1
	fi
done

$ESUDO chmod 666 /dev/uinput
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"
$GPTOKEYB "fallout2-ce" -c "./fallout2.gptk.$ANALOGSTICKS" -hotkey back &
./fallout2-ce 2>&1 | tee -a ./log.txt

$ESUDO kill -9 $(pidof gptokeyb)
unset SDL_GAMECONTROLLERCONFIG
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1
