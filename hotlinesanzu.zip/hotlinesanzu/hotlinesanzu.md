
## Notes

## Controls

|Button| Action |
|--|--|
| l-stick| movement |
| r-stick| aim |
| r2| shoot |
| l2| melee |
| a| interact/confirm |
| b| bomb/cancel |
| l1| focus mode |
| start| pause |
| select| hold to restart |
