#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

$ESUDO chmod 666 /dev/tty1

if [[ ! -z $(cat /storage/.config/.OS_ARCH | grep "351V") ]] || [[ -e "/boot/rk3326-rg351v-linux.dtb" ]] || [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]] || [[ -e "/dev/input/by-path/platform-gameforce-gamepad-event-joystick" ]] || [[ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG552" ]] || [[ -e "/dev/input/by-path/platform-singleadc-joypad-event-joystick" ]]; then
  if [[ -e /$directory/ports/soniccd/settings.ini.640 ]]; then
    mv /$directory/ports/soniccd/settings.ini.640 /$directory/ports/soniccd/settings.ini
  fi
fi

export LD_LIBRARY_PATH=/$directory/ports/soniccd/libs:/usr/lib:/usr/lib32
cd /$directory/ports/soniccd
$GPTOKEYB "soniccd" &
SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./soniccd
$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
printf "\033c" > /dev/tty1