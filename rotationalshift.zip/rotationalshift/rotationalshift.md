
## Notes

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement |
| a| jump |
| b/x| grab/throw |
| start| enter |
