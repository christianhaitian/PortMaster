Freegemas

Freegemas is an open source version of the well known Bejeweled

Developer: José Tomás Tocino
URL: https://github.com/JoseTomasTocino/freegemas

CONTROLS
=========

select = reset
start = esc

a = mouse_right
b = mouse_left
y - hint


r1 = mouse_slow

up = up
down = down
left = left
right = right

left_analog_up = mouse_movement_up
left_analog_down = mouse_movement_down
left_analog_left = mouse_movement_left
left_analog_right = mouse_movement_right