
## Notes:

## Controls

|Button| Action |
|--|--|
| d-pad/up/down| movement |
| b| fire/select |
| a| return |
| select+start| exit game |