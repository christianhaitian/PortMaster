#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

cd /$directory/ports/rawgl/
$ESUDO $controlfolder/oga_controls rawgl $param_device &
if [[ $LOWRES == "Y" ]]; then
  LD_LIBRARY_PATH=./libs:$LD_LIBRARY_PATH SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./rawgl --window=480x320 --render=software --datapath="/roms/ports/rawgl/gamedata" --language=us 2>&1 | tee ./log.txt
else
  LD_LIBRARY_PATH=./libs:$LD_LIBRARY_PATH SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./rawgl --window=640x480 --render=software --datapath="/$directory/ports/rawgl/gamedata" --language=us 2>&1 | tee ./log.txt
fi
$ESUDO kill -9 $(pidof oga_controls)
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1

