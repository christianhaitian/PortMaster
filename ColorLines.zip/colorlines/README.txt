https://github.com/Limows/SDL-ColorLines

Forked and updated version of SDL re-implementation of classic Color Lines game, originally written by Nikita Zimin in 2010

Controls

A/B - Enter
X - In game disable/enable sound
Y - Reset game
dpap/left/right stick - Move
Select - In game back / In menu quit
Start - About