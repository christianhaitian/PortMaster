Descent 1 and 2 Portmaster ReadMe

* Based on the work from:
	https://www.dxx-rebirth.com
	https://github.com/krishenriksen/AnberPorts

* The builds seem to have SDL2 issues that were introduced when the DXX-Rebirth project migrated from SDL1 to SDL2. This breaks loading music from the original game data. The remastered music add-ons from DXX-rebirth are required if you want music.
	see https://www.dxx-rebirth.com/addons/

* game data files go in the Data folder

descent/Data/
	DESCENT.HOG
	DESCENT.PIG
	d1xr-hires.dxa		
		(optional https://www.dxx-rebirth.com/addons/)
	d1xr-sc55-music.dxa or d1xr-opl3-music.dxa
		(required for music https://www.dxx-rebirth.com/addons/ 
	
descent2/Data
	d2xr-sc55-music.dxa or d2xr-opl3-music.dxa
		(required for music https://www.dxx-rebirth.com/addons/)
	descent2.ham
	descent2.hog
	descent2.s11
	descent2.s22
	alien1.pig	
	alien2.pig	
	fire.pig
	ice.pig
	water.pig
	groupa.pig	
	intro-h.mvl
	robots-h.mvl
	other-h.mvl




