Retro Time

RetroTime is a game containing 8 retro based games playable in 3 game modes being Retro Carousel, Time Attack and Lives mode. 


Developer: Willems Davy (https://github.com/joyrider3774)
URL: https://github.com/joyrider3774/RetroTime



CONTROLS
========

Key / Button	Action
Joystick, D-Pad, Arrow keys	Directional movement of the player, making selections in the menu's
A button or Space key	Confirming in menus, the main game action
B & Back button or Esc Key	Back in menus
B button or Ctrl key	Secondary action in blockstacker game
Start button or Esc Key	Confirming in menus, Pausing during gameplay
F4 key	Immediatly Quit the game
F3 key	Switch between fullscreen & windowed mode