DungeonRush

A opensource game inspired by Snake, written in pure C with SDL

Developer: Yujia Qiao / rapiz1
URL: https://github.com/Rapiz1/DungeonRush

CONTROLS
=========

dpad up = up
dpad down = down
dpad left = left
dpad right = right

left_analog_up = up
left_analog_down = down
left_analog_left = left
left_analog_right = right

right_analog_up = up
right_analog_down = down
right_analog_left = left
right_analog_right = right

start = enter
a = enter
x = enter

b = esc
y = esc
back/select = esc


Release Note
v1.1-beta
Fix bugs
v1.0-beta
Fix bugs
Add Multiplayer / LAN mode
You can play with your friend via Internet! You need to be in the same network and can directly connect by IP

v1.0-alpha
Initial release



Collect heros to enlarge your army while defending yourself from the monsters. Each level has a target length of the hero queue. Once it's reached, you will be sent to the next level and start over. There are lots of stuff that will be adjusted according to the level you're on, including factors of HP and damage, duration of Buffs and DeBuffs, the number and strength of monsters and so on.

Weapons
There are powerful weapons randomly dropped by the monsters. Different kinds of heros can be equipped with different kind of weapons.

Buff/DeBuff
There's a possibility that the attack from one with weapon triggers certain Buff on himself or DeBuff on the enemy.

IceSword can frozen enemies.
HolySword can give you a shield that absorbs damage and makes you immune to DeBuff.
GreatBow can increase the damage of all your heros' attack.
And so on.
For sure, some kinds of monsters have weapons that can put a DeBuff on you! (Like the troublesome muddy monsters can slow down your movement.)