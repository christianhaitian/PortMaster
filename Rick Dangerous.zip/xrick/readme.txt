this system is a port of Rick Dangerous. data.zip required.
