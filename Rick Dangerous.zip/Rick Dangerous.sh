#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

whichos=$(grep "title=" "/usr/share/plymouth/themes/text.plymouth")
if [[ $whichos == *"TheRA"* ]]; then
  raloc="/opt/retroarch/bin"
elif [[ -e "/storage/.config/.OS_ARCH" ]] || [ "${OS_NAME}" == "JELOS" ]; then
  raloc="/usr/bin"
else
  raloc="/usr/local/bin"
fi

GAMEDIR="/$directory/ports/xrick"

$raloc/retroarch -L $GAMEDIR/xrick_libretro.so $GAMEDIR
