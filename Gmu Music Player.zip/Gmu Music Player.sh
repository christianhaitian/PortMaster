#!/bin/bash

ESUDO="sudo"
ESUDOKILL="-sudokill"
if [ -f "/storage/.config/.OS_ARCH" ]; then
  ESUDO=""
  ESUDOKILL="-1" # -1 (numeric one) or "-k" for EmuELEC
fi

# set analog sticks variable to 2 here as default in case PortMaster fails configuration for any reason
ANALOGSTICKS=2


#PortMaster initialization

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "/roms/ports/PortMaster" ]; then
  controlfolder="/roms/ports/PortMaster"
elif [ -d "/roms2/ports/PortMaster" ]; then
  controlfolder="/roms2/ports/PortMaster"
else
  controlfolder="/storage/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

#End PortMaster initialization


GAMEDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/gmu-music-player"
LIBDIR=$GAMEDIR/libs
GPTOKEYB="$GAMEDIR/gptokeyb $ESUDOKILL"


if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
      param_device="anbernic"
      hotkey="Select"
      DEVICE="03000000091200000031000011010000"
      sdl_controllerconfig="03000000091200000031000011010000,OpenSimHardware OSH PB Controller,a:b0,b:b1,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,dpup:h0.1,leftx:a0~,lefty:a1~,guide:b12,leftstick:b8,lefttrigger:b10,rightstick:b9,back:b7,start:b6,rightx:a2,righty:a3,righttrigger:b11,platform:Linux,"
      ANALOGSTICKS=2
      SCREENW="480"
      SCREENH="320"
      GMU_CONFIG="gmu.rg351p.conf"
      if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ] || [ -f "/opt/system/Advanced/Switch to SD2 for Roms.sh" ] || [ -f "/boot/rk3326-rg351v-linux.dtb" ]; then
        param_device="anbernic"
        hotkey="Select"
        DEVICE="03000000091200000031000011010000"
        sdl_controllerconfig="03000000091200000031000011010000,OpenSimHardware OSH PB Controller,a:b0,b:b1,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,dpup:h0.1,leftx:a0~,lefty:a1~,guide:b12,leftstick:b8,lefttrigger:b10,rightstick:b9,back:b7,start:b6,rightx:a2,righty:a3,righttrigger:b11,platform:Linux,"
        ANALOGSTICKS=1
        SCREENW="640"
        SCREENH="480"
        GMU_CONFIG="gmu.rg351v.conf"
      fi
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      param_device="oga"
      hotkey="Minus"
      DEVICE="190000004b4800000010000001010000"
      sdl_controllerconfig="190000004b4800000010000001010000,GO-Advance Gamepad (rev 1.1),a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b9,dpleft:b10,dpright:b11,dpup:b8,leftx:a0,lefty:a1,guide:b12,leftstick:b14,lefttrigger:b13,rightstick:b15,righttrigger:b16,start:b17,platform:Linux,"
      ANALOGSTICKS=1
      SCREENW="480"
      SCREENH="320"
      GMU_CONFIG="gmu.rg351p.conf"
	else
      param_device="rk2020"
      hotkey="Select"
      DEVICE="190000004b4800000010000000010000"
      sdl_controllerconfig="190000004b4800000010000000010000,GO-Advance Gamepad,a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b7,dpleft:b8,dpright:b9,dpup:b6,leftx:a0,lefty:a1,back:b10,lefttrigger:b12,righttrigger:b13,start:b15,platform:Linux,"
      ANALOGSTICKS=1
      SCREENW="480"
      SCREENH="320"
      GMU_CONFIG="gmu.rg351p.conf"
   fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
      param_device="ogs"
      hotkey="Select"
      DEVICE="190000004b4800000011000000010000"
      sdl_controllerconfig="190000004b4800000011000000010000,GO-Super Gamepad,platform:Linux,x:b2,a:b1,b:b0,y:b3,back:b12,guide:b16,start:b13,dpleft:b10,dpdown:b9,dpright:b11,dpup:b8,leftshoulder:b4,lefttrigger:b6,rightshoulder:b5,righttrigger:b7,leftstick:b14,rightstick:b15,leftx:a0,lefty:a1,rightx:a2,righty:a3,platform:Linux,"
      ANALOGSTICKS=2
      #SCREENW="854"  --The Odroid Go Super has a 848x480 display, but the RG351MP has a 640x480 res
      SCREENW="640"
      SCREENH="480"
      GMU_CONFIG="gmu.rg351mp.conf"
elif [[ -e "/dev/input/by-path/platform-gameforce-gamepad-event-joystick" ]]; then
      param_device="chi"
      hotkey="1"
      DEVICE="19000000030000000300000002030000"
      sdl_controllerconfig="19000000030000000300000002030000,gameforce_gamepad,leftstick:b14,rightx:a3,leftshoulder:b4,start:b9,lefty:a0,dpup:b10,righty:a2,a:b1,b:b0,guide:b16,dpdown:b11,rightshoulder:b5,righttrigger:b7,rightstick:b15,dpright:b13,x:b2,back:b8,leftx:a1,y:b3,dpleft:b12,lefttrigger:b6,platform:Linux,"
      ANALOGSTICKS=2
      SCREENW="640"
      SCREENH="480"
      GMU_CONFIG="gmu.rg351mp.conf"
elif [[ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG552" ]]; then
      param_device="rg552"
      hotkey="L3"
      DEVICE="190000004b4800000111000000010000"
      sdl_controllerconfig="190000004b4800000111000000010000,retrogame_joypad,a:b1,b:b0,x:b2,y:b3,back:b8,start:b9,rightstick:b12,leftstick:b11,dpleft:b15,dpdown:b14,dpright:b16,dpup:b13,leftshoulder:b4,lefttrigger:b6,rightshoulder:b5,righttrigger:b7,leftx:a0,lefty:a1,rightx:a2,righty:a3,platform:Linux,"
      ANALOGSTICKS=2
      SCREENW="1920"
      SCREENH="1152"
      GMU_CONFIG="gmu.rg351mp.conf"
elif [ -e "/dev/input/by-path/platform-singleadc-joypad-event-joystick" ] || [ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG503" ]; then
      param_device="rg503"
      hotkey="Select"
      DEVICE="190000004b4800000111000000010000"
      sdl_controllerconfig="190000004b4800000111000000010000,retrogame_joypad,a:b1,b:b0,x:b2,y:b3,back:b8,start:b9,rightstick:b12,leftstick:b11,dpleft:b15,dpdown:b14,dpright:b16,dpup:b13,leftshoulder:b4,lefttrigger:b6,rightshoulder:b5,righttrigger:b7,leftx:a0,lefty:a1,rightx:a2,righty:a3,platform:Linux,"
      ANALOGSTICKS=2
      SCREENW="960"
      SCREENH="544"
      GMU_CONFIG="gmu.rg351mp.conf"
else
      DEVICE="${1}"
      param_device="${2}"
      hotkey="Select"
      SCREENW="640"
      SCREENH="480"
      GMU_CONFIG="gmu.rg351mp.conf"
fi

cd $GAMEDIR

    CONTROLS=`./grep "${SDLDBUSERFILE}" -e "${DEVICE}"`
    [ -z "${CONTROLS}" ] && CONTROLS=`./grep "${SDLDBFILE}" -e "${1}"`
    sdl_controllerconfig="${CONTROLS}"


$ESUDO chmod 666 /dev/tty0
$ESUDO chmod 666 /dev/tty1
$ESUDO chmod 666 /dev/uinput

# system
export TERM=linux
export XDG_RUNTIME_DIR=/run/user/$UID/
export LD_LIBRARY_PATH=$LIBDIR


$ESUDO chmod ugo+rwx -R $GAMEDIR


export SDL_GAMECONTROLLERCONFIG_FILE="$GAMEDIR/gamecontrollerdb.txt"
export SDL_GAMECONTROLLERCONFIG="$(cat $GAMEDIR/gamecontrollerdb.txt)"


$ESUDO rm $GAMEDIR/log.txt
sleep 1


$GPTOKEYB "gmu.bin" -c "$GAMEDIR/gmu.gptk" &
./gmu.bin -c $GMU_CONFIG 2>&1 | tee -a $GAMEDIR/log.txt


$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
pgrep -f gmu.bin | $ESUDO xargs kill -9
unset SDL_GAMECONTROLLERCONFIG
printf "\033c" > /dev/tty1
printf "\033c" >> /dev/tty1