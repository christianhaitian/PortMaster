Wordle SDL

Wordle SDL is a port of a clone of Wordle made with SDL.

Wordle is a web-based word game created and developed by Welsh software engineer Josh Wardle, and owned and published by The New York Times Company since 2022. 
Players have six attempts to guess a five-letter word, with feedback given for each guess in the form of colored tiles indicating when letters match or occupy the 
correct position.

Developer: Andrei Rafael (https://github.com/AndreiRafael)
URL: https://github.com/AndreiRafael/wordle_clone

Some logic for controls take from https://github.com/Rinnegatamante/wordle_clone


CONTROLS
========

Dpad and and Left stick up/down & left/right = scroll through letters

A = Confirm letter selection
B = Undo letter selection
Y = Confirm word
X = Confirm word

Start + Select = Exit