#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

GAMEDIR=/$directory/ports/shadow-warrior
cd $GAMEDIR

sudo rm -rf ~/.jfsw
sudo ln -s /$GAMEDIR/conf/.jfsw ~/
$ESUDO chmod 666 /dev/uinput
$GPTOKEYB "sw" &
LD_LIBRARY_PATH=./libs:$LD_LIBRARY_PATH SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./sw 2>&1
$ESUDO systemctl restart oga_events &
pgrep -f sw | $ESUDO xargs kill -9
unset SDL_GAMECONTROLLERCONFIG
printf "\033c" >> /dev/tty1
