var Scenario = {

    /**
     * Default scenario settings (random)
     *
     * @param {number} pPhaseNumber Current phase number
     */
    Settings: function( pPhaseNumber ) {
        Settings.Random();
    },

};
