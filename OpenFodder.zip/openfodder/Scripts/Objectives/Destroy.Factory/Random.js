
Objectives.DestroyFactory.Random = function(pCount) {
	
	// TODO
};
