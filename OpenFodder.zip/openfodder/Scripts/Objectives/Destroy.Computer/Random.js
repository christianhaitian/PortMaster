
Objectives.DestroyComputer.Random = function(pCount) {
	
	// TODO
};
