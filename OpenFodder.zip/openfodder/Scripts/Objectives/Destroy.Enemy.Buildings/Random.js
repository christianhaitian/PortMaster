
/**
 * 
 */
Objectives.DestroyEnemyBuildings.Random = function(pEnemyBuildings) {
	print("Placing enemy buildings");

	Structures.PlaceBuildings(pEnemyBuildings);

};
