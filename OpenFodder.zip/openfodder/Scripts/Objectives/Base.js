
var Objectives = {
	
	KillAllEnemy: {
		ID: 1
	},
	DestroyEnemyBuildings: {
		ID: 2
	},
	RescueHostages: {
		ID: 3
	},
	ProtectCivilians: {
		ID: 4
	},
	KidnapLeader: {
		ID: 5
	},
	DestroyFactory: {
		ID: 6
	},
	DestroyComputer: {
		ID: 7
	},
	GetCivilianHome: {
		ID: 8
	},

	// CF2 Only
	ActivateSwitches: {
		ID: 9
	},
	RescueHostage: {
		ID: 10
	}
	
};
