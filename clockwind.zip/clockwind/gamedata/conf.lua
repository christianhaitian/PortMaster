function love.conf(t)
	t.version = "11.0"
	t.window = false
	--t.console = true
end