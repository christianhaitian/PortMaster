
## Notes

Special thanks to Kultisti at https://kultisti.itch.io/snaklipse for creating the game and allowing us to distribute the files.

## Controls

|Button| Action |
|--|--|
| select| pause |
| d-pad/l-stick| movement |
| abxy| jump |
