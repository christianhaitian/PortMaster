
## Notes

Special thanks to Maybell at https://maybell.itch.io/ for allowing us to distribute the game files.

## Controls

|Button| Action |
|--|--|
| L-stick/d-pad| movement  |
| R-stick/ABXY| attack |
| L1/L2/R1/R2 | toggle auto-fire
| Select| back/pause |
| Start| enter/select |