
## Notes

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement |
| a| jump |
| b| dodge (unlockable) |
| x| attack |
| y| throw sword (unlockable) |
| start| pause |
