xkcd Hoverboard

xkcd Hoverboard is a standalone version of xkcd 1608 "Hoverboard" game.


Developer: Dmitry Marakasov (https://github.com/AMDmi3)
URL: https://github.com/AMDmi3/hoverboard-sdl



CONTROLS
========

dpad - left/right
A/B/Y - jump
X - Toggle map
Start - Toggle map
Back - Quit
L1/L2 - Load save state
R1/R2 - Save state