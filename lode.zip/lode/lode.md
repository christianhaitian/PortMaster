
## Notes

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement |
| a| interact |
| b| hold to restart level |
| x| pickup/throw |
| l1+direction| look |
