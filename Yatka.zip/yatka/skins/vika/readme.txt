The skin was developed as an idea of my girlfriend, as she could not have stood sorrow and pain of the legacy skin.

The font from fontsquirrel.com.
The background from wallpaperaccess.com.
