The legacy skin created out of my depression and disillusionment with my job and reality around me.

The font by Yuji Adachi.
The background from Berserk manga.
