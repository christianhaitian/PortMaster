#!/bin/bash

if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
  param_device="anbernic"
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
	  param_device="oga"
	else
	  param_device="rk2020"
	fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  param_device="ogs"
else
  param_device="chi"
fi

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  GAMEDIR="/roms2/ports/smw"
  LIBDIR="/roms2/ports/smw/lib32"
  BINDIR="/roms2/ports/smw/box86"
else
  GAMEDIR="/roms/ports/smw"
  LIBDIR="/roms/ports/smw/lib32"
  BINDIR="/roms/ports/smw/box86"
fi

cd $GAMEDIR

sudo rm -rf ~/.smw
sudo ln -s /$GAMEDIR/conf/.smw ~/
sudo ./oga_controls smw $param_device &
./smw
sudo kill -9 $(pidof oga_controls)
sudo systemctl restart oga_events &
printf "\033c" >> /dev/tty1
