
## Notes

Thanks to Harley Wilson at https://hwilson.itch.io/pocket-wonder-sport for creating the game and allowing us to distribute.

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement |
| a| confirm/action |
| select/l3| menu |
| start| pause |