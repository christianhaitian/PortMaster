#!/bin/bash

ESUDO="sudo"
ESUDOKILL="-sudokill"
if [ -f "/storage/.config/.OS_ARCH" ]; then
  ESUDO=""
  ESUDOKILL="-1" # -1 (numeric one) or "-k" for EmuELEC
fi

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  directory="roms2/ports/bstone"
else
  directory="roms/ports/bstone"
fi

if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
  sdl_controllerconfig="03000000091200000031000011010000,OpenSimHardware OSH PB Controller,a:b1,b:b0,x:b3,y:b2,leftshoulder:b4,rightshoulder:b5,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,dpup:h0.1,leftx:a0~,lefty:a1~,leftstick:b8,lefttrigger:b10,rightstick:b9,back:b7,start:b6,rightx:a2,righty:a3,righttrigger:b11,platform:Linux,"
  param_device="anbernic"
  if [ -f "/boot/rk3326-rg351v-linux.dtb" ] || [ $(cat "/storage/.config/.OS_ARCH") == "RG351V" ]; then
    GPTOKEYB_CONFIG="bstone.gptk.rg351.leftanalog"  
    $ESUDO sed -i '/vid_width / s/"480"/"640"/' /$directory/conf/bibendovsky/bstone/bstone_config.txt
    $ESUDO sed -i '/vid_height / s/"320"/"480"/' /$directory/conf/bibendovsky/bstone/bstone_config.txt
  else
    GPTOKEYB_CONFIG="bstone.gptk"
    $ESUDO sed -i '/vid_width / s/"640"/"480"/' /$directory/conf/bibendovsky/bstone/bstone_config.txt
    $ESUDO sed -i '/vid_height / s/"480"/"320"/' /$directory/conf/bibendovsky/bstone/bstone_config.txt
  fi
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      sdl_controllerconfig="190000004b4800000010000001010000,GO-Advance Gamepad (rev 1.1),a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b9,dpleft:b10,dpright:b11,dpup:b8,leftx:a0,lefty:a1,back:b12,leftstick:b13,lefttrigger:b14,rightstick:b16,righttrigger:b15,start:b17,platform:Linux,"
	  param_device="oga"
	else
	  sdl_controllerconfig="190000004b4800000010000000010000,GO-Advance Gamepad,a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b7,dpleft:b8,dpright:b9,dpup:b6,leftx:a0,lefty:a1,back:b10,lefttrigger:b12,righttrigger:b13,start:b15,platform:Linux,"
	  param_device="rk2020"
	fi
    GPTOKEYB_CONFIG="bstone.gptk.leftanalog"
    $ESUDO sed -i '/vid_width / s/"640"/"480"/' /$directory/conf/bibendovsky/bstone/bstone_config.txt
    $ESUDO sed -i '/vid_height / s/"480"/"320"/' /$directory/conf/bibendovsky/bstone/bstone_config.txt
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  sdl_controllerconfig="190000004b4800000011000000010000,GO-Super Gamepad,platform:Linux,x:b2,a:b1,b:b0,y:b3,back:b12,guide:b14,start:b13,dpleft:b10,dpdown:b9,dpright:b11,dpup:b8,leftshoulder:b4,lefttrigger:b6,rightshoulder:b5,righttrigger:b7,leftstick:b15,rightstick:b16,leftx:a0,lefty:a1,rightx:a2,righty:a3,platform:Linux,"
  param_device="ogs"
  GPTOKEYB_CONFIG="bstone.gptk"
  $ESUDO sed -i '/vid_width / s/"480"/"640"/' /$directory/conf/bibendovsky/bstone/bstone_config.txt
  $ESUDO sed -i '/vid_height / s/"320"/"480"/' /$directory/conf/bibendovsky/bstone/bstone_config.txt
else
  sdl_controllerconfig="19000000030000000300000002030000,gameforce_gamepad,leftstick:b14,rightx:a3,leftshoulder:b4,start:b9,lefty:a0,dpup:b10,righty:a2,a:b1,b:b0,guide:b16,dpdown:b11,rightshoulder:b5,righttrigger:b7,rightstick:b15,dpright:b13,x:b2,back:b8,leftx:a1,y:b3,dpleft:b12,lefttrigger:b6,platform:Linux,"
  param_device="chi"
  GPTOKEYB_CONFIG="bstone.gptk"
  $ESUDO sed -i '/vid_width / s/"480"/"640"/' /$directory/conf/bibendovsky/bstone/bstone_config.txt
  $ESUDO sed -i '/vid_height / s/"320"/"480"/' /$directory/conf/bibendovsky/bstone/bstone_config.txt
fi

cd /$directory

$ESUDO rm -rf ~/.local/share/bibendovsky
ln -sfv /$directory/conf/bibendovsky ~/.local/share/

$ESUDO chmod 666 /dev/uinput
SDL_GAMECONTROLLERCONFIG_FILE="./gamecontrollerdb.txt" ./gptokeyb $ESUDOKILL "bstone" -c "./$GPTOKEYB_CONFIG" &
LD_LIBRARY_PATH="$PWD/libs" SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./bstone --data_dir gamedata/aliens_of_gold  2>&1 | tee -a ./log.txt
$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1
