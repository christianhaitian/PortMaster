-----------------------------------------

THE CURSE OF ISSYOS �2015
version 1.002

A game by Locomalito
Music by Gryzor87

Promotional art by Marek Barej 
and Jacobo Garc�a

-----------------------------------------

DEFAULKT KEYS

Arrows ---- Move around
Z --------- Attack
X --------- Jump
Esc ------- Pause menu

You can set your own keys in the menu.
XInput and DInput controllers supported.
Keyboard input will be overridden if a
controller is detected.

-----------------------------------------

Configuration and hiscore files are
stored in your local App data folder,
not in the same folder of the program.

-----------------------------------------

THIS IS A FREEWARE/DONATIONWARE GAME

You can support my project with a
a donation or writing about this or
my other games. 

For more info visit www.locomalito.com

-----------------------------------------

Have fun :-)

-----------------------------------------