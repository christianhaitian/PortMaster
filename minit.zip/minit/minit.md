
## Notes

## Controls

|Button| Action |
|--|--|
| dpad/l-stick = movement |
| a| use/ok |
| b| kill self/retry |