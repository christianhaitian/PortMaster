
## Notes

Thanks to Harley Wilson at https://hwilson.itch.io/hunters for creating the game and allowing us to distribute the files.

## Controls

|Button| Action |
|--|--|
| d-pad/l-stick| movement |
| a| shoot/confirm |
| b| boost/cancel |
| start| pause/upgrades menu |