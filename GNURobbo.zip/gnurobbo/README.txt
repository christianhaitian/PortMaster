GNU Robbo

https://github.com/bomblik/GNU_Robbo_PSVITA_PSP

GNU Robbo is a free open source reimplementation of game designed by Janusz Pelc and published by LK Avalon in 1989 for the Atari XL/XE computers. 
A success on the Polish domestic market, it was later ported to other computer platforms and also released in the United States as The Adventures of Robbo.


Controls
---------
Start - Enter/Confirm
Select - Esc
A/B/Y + Dpad/Lstick - Shoot
X - Restart
R1/2 = Next level pack
L1/2 - Previous level pack