Me and My Shadow

Me and My Shadow is a free libre puzzle/platform game in which you try to reach the exit by solving puzzles. Spikes, moving blocks, 
fragile blocks and much more stand between you and the exit. Record your moves and let your shadow mimic them to reach blocks you couldn't reach alone.


Developer: Jz Pan (https://github.com/acmepjz)
URL: https://github.com/acmepjz/meandmyshadow



CONTROLS
========

Dpad and Left stick - left/right
A - Enter/Confirm
B - Jump
Y- Toggle Record
X - Reset level

L/R - Tab

Select = Esc/Back
Strart - Enter