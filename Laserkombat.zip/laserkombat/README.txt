Laser Kombat

Laser Kombat is a classic puzzle game, now available for modern systems. Destroy all the tanks to beat the level. Stay out 
of line of sight, though, or you will get shot. Shoot your lasers at mirrors, blow up bomb or push your enemies 
into water with movable blocks to win.


Developer: Wouter Wijsman (https://github.com/sharkwouter)
URL: https://github.com/sharkwouter/laserkombat


CONTROLS
========
Start = Restart
Select = Esc
Start + Select = Exit

Dpad and left stick = movement

A = Fire
B = Undo
X = Save state
Y = Restore state

l1/l2 = Previous level
r1/r2 = Next level