Art assets in this plugin are based on art from the Marathon series, copyright Bungie. Please contact Bungie before using these assets for any commercial purpose, or any purpose not directly connected with the Marathon community.

The Squarish Sans typeface was created by Tim Larson. See the readme file within the "resources" directory for information.

The DejaVu typefaces were produced by Bitstream and others. See the readme file within the "resources" directory for information.
