#!/bin/bash

source /etc/profile

cd /storage/roms/ports/bugdom/

./Bugdom | tee ./log.txt
