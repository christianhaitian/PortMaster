Znax

Znax is a remake of a game by Nick Kouvaris. It is a sort of puzzle / arcade game where you as the player need to select 4 blocks of the same color 
and form rectangles as big as you can. By doing this you will erase all blocks in this rectangle and they will be replaced by new blocks. You keep on 
doing this till the time runs out, and try to gain your highest score possible. There are two game modes, Relative timer and fixed Timer, in the first 
mode you'll also gain extra time for deleting blocks so you can play longer if you are fast enough. With the second mode you don't get extra time for 
deleting blocks but just points added to your score so here you try to get the highest amount of points in the given time period.


Developer: Willems Davy (https://github.com/joyrider3774)
URL: https://github.com/joyrider3774/Znax


CONTROLS
========

Start = Enter
Select = Back/Esc
Start + Select = Exit

Dpad and left stick = move left/right

A = Select
Y = Cycle theme

