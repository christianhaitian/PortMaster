Multris

A version of Tetris with randomly generated polyominoes of varying sizes

Developer: https://github.com/RustyReich
URL: https://github.com/RustyReich/Multris

CONTROLS
========



LEFT / RIGHT - Move. Hold to move quicker.
DOWN - Soft Drop
UP - Hard Drop
A - Hold current piece / Swap current piece with held piece
R1/R2 - Rotate CCW
L1/L2 - Rotate CW
B - Mirror piece over Y-Axis
Start - Select/Pause
Select - Exit the game if pressed in the menu

