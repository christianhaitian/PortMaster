#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "/roms/roms/ports" ]; then
  controlfolder="/roms/ports/PortMaster"
else
  controlfolder="/storage/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

cd /$directory/ports/iconoclasts/gamedata

export CHOWDREN_FPS=30
export LIBGL_FB_TEX_SCALE=0.5
export LIBGL_SKIPTEXCOPIES=1
export LIBGL_ES=2
export LIBGL_GL=21
export LIBGL_FB=4
export BOX86_LOG=1
export BOX86_ALLOWMISSINGLIBS=1
export BOX86_DLSYM_ERROR=1
export SDL_DYNAMIC_API=libSDL2-2.0.so.0
export BOX86_LD_PRELOAD=/$directory/ports/iconoclasts/libIconoclasts.so
export SDL_VIDEO_GL_DRIVER=/$directory/ports/iconoclasts/box86/native/libGL.so.1
export SDL_VIDEO_EGL_DRIVER=/$directory/ports/iconoclasts/box86/native/libEGL.so.1
export LD_LIBRARY_PATH=/$directory/ports/iconoclasts/box86/native:/usr/lib/arm-linux-gnueabihf/:/usr/lib32:/usr/config/emuelec/lib32
export BOX86_LD_LIBRARY_PATH=/$directory/ports/iconoclasts/box86/lib:/usr/lib/arm-linux-gnueabihf/:./:lib/:lib/bin32/:x86/
export BOX86_DYNAREC=1
export BOX86_FORCE_ES=31
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

# load user settings
source /$directory/ports/iconoclasts/settings.txt

$ESUDO chmod 666 /dev/tty0
printf "\033c" > /dev/tty0

if [ ! -f 'bin32/Chowdren' ]; then
	# No game found, check for installers...
	for installer in iconoclasts_*.sh; do break; done;
	if [[ -z "$installer" ]] || [[ "$installer" == "iconoclasts_*.sh" ]]; then
		echo "No data, no installer... nothing to do :("
		printf "\033c" > /dev/tty1
		exit -1
	fi

	echo "Installing from $installer..." > /dev/tty0

	# extract the installer, but make sure we got the Chowdren binary present!
	python3 ../extract.py "$installer" "data/noarch/game/bin32/Chowdren" > /dev/tty0
	if [ $? != 0 ]; then
		echo "Install failed..." > /dev/tty0
		wait 5
		printf "\033c" > /dev/tty1
		exit -1
	fi
fi

$ESUDO chmod 666 /dev/uinput
$GPTOKEYB "box86" -c "/$directory/ports/iconoclasts/iconoclasts.gptk" &
echo "Loading, please wait... (might take a while!)" > /dev/tty0
/$directory/ports/iconoclasts/box86/box86 bin32/Chowdren
$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
unset SDL_GAMECONTROLLERCONFIG
printf "\033c" >> /dev/tty1