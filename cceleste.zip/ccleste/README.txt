Celeste Classic

Celeste Classic is a C source port of the original celeste (Celeste classic).


Developer: lemon (https://github.com/lemon32767)
URL: https://github.com/lemon32767/ccleste


CONTROLS
========

Start/Select = Pause

Start+Select = Exit

Dpad  and Left stick = left/right and look up/down
Right Stick = left/right

A = Jump
B = Dash
Y = Hold to reset
X = Toggle screenshake

l1/l2 = Load state
r1/r2 - Save state

Start + Select = Exit