#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

GAMEDIR=/$directory/ports/Exhumed

if   [[ $ANALOGSTICKS == '1' ]]; then
  if [ ! -f "/roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg" ]; then
     mv -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.1analog /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg
     rm -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.2analog
  fi
  if [ ! -f "/roms/ports/Exhumed/oga_controls_settings.txt" ]; then
     mv -f /roms/ports/Exhumed/oga_controls_settings.txt.1analog /roms/ports/Exhumed/oga_controls_settings.txt
     rm -f /roms/ports/Exhumed/oga_controls_settings.txt.2analog
  fi
elif [[ $ANALOGSTICKS == '2' ]]; then
  if [ ! -f "/roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg" ]; then
     mv -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.2analog /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg
     rm -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.1analog
  fi
  if [ ! -f "/roms/ports/Exhumed/oga_controls_settings.txt" ]; then
     mv -f /roms/ports/Exhumed/oga_controls_settings.txt.2analog /roms/ports/Exhumed/oga_controls_settings.txt
     rm -f /roms/ports/Exhumed/oga_controls_settings.txt.1analog
  fi
fi

$ESUDO rm -rf ~/.config/pcexhumed
$ESUDO ln -s /roms/ports/Exhumed/conf/pcexhumed ~/.config/
cd $GAMEDIR
$ESUDO ./oga_controls pcexhumed $param_device &
LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./pcexhumed 2>&1 | tee ./log.txt
$ESUDO kill -9 $(pidof oga_controls)
unset SDL_GAMECONTROLLERCONFIG
$ESUDO systemctl restart oga_events &
pgrep -f pcexhumed | $ESUDO xargs kill -9
printf "\033c" >> /dev/tty1