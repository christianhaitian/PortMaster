#!/bin/bash

ESUDO="sudo"
if [ -f "/storage/.config/.OS_ARCH" ]; then
  ESUDO=""
fi

if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
  param_device="anbernic"
  sdl_controllerconfig="03000000091200000031000011010000,OpenSimHardware OSH PB Controller,a:b0,b:b1,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:h0.4,dpleft:h0.8,dpright:h0.2,dpup:h0.1,leftx:a0~,lefty:a1~,guide:b12,leftstick:b8,lefttrigger:b10,rightstick:b9,back:b7,start:b6,rightx:a2,righty:a3,righttrigger:b11,platform:Linux,"
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      if [ ! -f "/roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg" ]; then
        mv -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.1analog /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg
        rm -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.2analog
      fi
      if [ ! -f "/roms/ports/Exhumed/oga_controls_settings.txt" ]; then
        mv -f /roms/ports/Exhumed/oga_controls_settings.txt.1analog /roms/ports/Exhumed/oga_controls_settings.txt
        rm -f /roms/ports/Exhumed/oga_controls_settings.txt.2analog
      fi
      param_device="oga"
      sdl_controllerconfig="190000004b4800000010000001010000,GO-Advance Gamepad (rev 1.1),a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b9,dpleft:b10,dpright:b11,dpup:b8,leftx:a0,lefty:a1,guide:b12,leftstick:b14,lefttrigger:b13,rightstick:b15,righttrigger:b16,start:b17,platform:Linux,"
	else
      if [ ! -f "/roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg" ]; then
        mv -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.1analog /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg
        rm -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.2analog
      fi
      if [ ! -f "/roms/ports/Exhumed/oga_controls_settings.txt" ]; then
        mv -f /roms/ports/Exhumed/oga_controls_settings.txt.1analog /roms/ports/Exhumed/oga_controls_settings.txt
        rm -f /roms/ports/Exhumed/oga_controls_settings.txt.2analog
      fi
	  param_device="rk2020"
	  sdl_controllerconfig="190000004b4800000010000000010000,GO-Advance Gamepad,a:b1,b:b0,x:b2,y:b3,leftshoulder:b4,rightshoulder:b5,dpdown:b7,dpleft:b8,dpright:b9,dpup:b6,leftx:a0,lefty:a1,guide:b10,leftstick:b12,lefttrigger:b11,rightstick:b13,righttrigger:b14,start:b15,platform:Linux,"
	fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  if [ ! -f "/roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg" ]; then
    mv -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.2analog /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg
    rm -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.1analog
  fi
  if [ ! -f "/roms/ports/Exhumed/oga_controls_settings.txt" ]; then
    mv -f /roms/ports/Exhumed/oga_controls_settings.txt.2analog /roms/ports/Exhumed/oga_controls_settings.txt
    rm -f /roms/ports/Exhumed/oga_controls_settings.txt.1analog
  fi
  param_device="ogs"
  sdl_controllerconfig="190000004b4800000011000000010000,GO-Super Gamepad,platform:Linux,x:b2,a:b1,b:b0,y:b3,back:b12,guide:b16,start:b13,dpleft:b10,dpdown:b9,dpright:b11,dpup:b8,leftshoulder:b4,lefttrigger:b6,rightshoulder:b5,righttrigger:b7,leftstick:b14,rightstick:b17,leftx:a0,lefty:a1,rightx:a2,righty:a3,platform:Linux,"
else
  if [ ! -f "/roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg" ]; then
    mv -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.2analog /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg
    rm -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.1analog
  fi
  if [ ! -f "/roms/ports/Exhumed/oga_controls_settings.txt" ]; then
    mv -f /roms/ports/Exhumed/oga_controls_settings.txt.2analog /roms/ports/Exhumed/oga_controls_settings.txt
    rm -f /roms/ports/Exhumed/oga_controls_settings.txt.1analog
  fi
  param_device="chi"
  sdl_controllerconfig="19000000030000000300000002030000,gameforce_gamepad,leftstick:b14,rightx:a3,leftshoulder:b4,start:b9,lefty:a0,dpup:b10,righty:a2,a:b1,b:b0,guide:b16,dpdown:b11,rightshoulder:b5,righttrigger:b7,rightstick:b15,dpright:b13,x:b2,back:b8,leftx:a1,y:b3,dpleft:b12,lefttrigger:b6,platform:Linux,"
fi

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  if [ ! -f "/roms2/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg" ]; then
    mv -f /roms2/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.2analog /roms2/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg
    rm -f /roms2/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.1analog
  fi
  if [ ! -f "/roms/ports/Exhumed/oga_controls_settings.txt" ]; then
    mv -f /roms2/ports/Exhumed/oga_controls_settings.txt.2analog /roms2/ports/Exhumed/oga_controls_settings.txt
    rm -f /roms2/ports/Exhumed/oga_controls_settings.txt.1analog
  fi
  $ESUDO rm -rf ~/.config/pcexhumed
  $ESUDO ln -s /roms2/ports/Exhumed/conf/pcexhumed ~/.config/
  cd "/roms2/ports/Exhumed/"
  $ESUDO ./oga_controls pcexhumed $param_device &
  LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./pcexhumed 2>&1
  $ESUDO kill -9 $(pidof oga_controls)
  unset SDL_GAMECONTROLLERCONFIG
  $ESUDO systemctl restart oga_events &
  pgrep -f pcexhumed | $ESUDO xargs kill -9
  printf "\033c" >> /dev/tty1
else
  if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
	  if [ ! -f "/roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg" ]; then
		mv -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.2analog /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg
		rm -f /roms/ports/Exhumed/conf/pcexhumed/pcexhumed.cfg.1analog
	  fi
	  if [ ! -f "/roms/ports/Exhumed/oga_controls_settings.txt" ]; then
		mv -f /roms/ports/Exhumed/oga_controls_settings.txt.2analog /roms/ports/Exhumed/oga_controls_settings.txt
		rm -f /roms/ports/Exhumed/oga_controls_settings.txt.1analog
	  fi
  fi
  $ESUDO rm -rf ~/.config/pcexhumed
  $ESUDO ln -s /roms/ports/Exhumed/conf/pcexhumed ~/.config/
  cd "/roms/ports/Exhumed/"
  $ESUDO ./oga_controls pcexhumed $param_device &
  LD_LIBRARY_PATH=./lib:$LD_LIBRARY_PATH SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig" ./pcexhumed 2>&1
  $ESUDO kill -9 $(pidof oga_controls)
  unset SDL_GAMECONTROLLERCONFIG
  $ESUDO systemctl restart oga_events &
  pgrep -f pcexhumed | $ESUDO xargs kill -9
  printf "\033c" >> /dev/tty1
fi
