These are fixed entities for several maps.  uHexen2 version 1.5.0-RC1 or
newer can load them automatically.  To see what was fixed in a map, see
the text file accompanying the ent file.  If you aren't happy with the
fixed entities for a map, just delete the ent file and the map's original
embedded entities will be used.

NOTE:  These fixed entities are generated against version 1.11 of Hexen2
maps.  They may lead to unexpected results with the original cdrom (1.03)
versions of the maps.
