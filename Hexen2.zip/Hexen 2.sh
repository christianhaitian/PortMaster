#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

GAMEDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/hexen2"

$ESUDO chmod 777 -R $GAMEDIR/*

ADDLPARAMS="-conwidth 340 -lm_2 +viewsize 120 +gl_glows 1 +gl_extra_dynamic_lights 1 +gl_missile_glows 1 +gl_other_glows 1 +gl_colored_dynamic_lights 1 +gl_coloredlight 2 +r_waterwarp 0 +showfps 0"

# Load directly into an expansion, a map, or a mod
#RUNMOD="+map hexn1"


if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
      SCREENW="480"
      SCREENH="320"
      if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ] || [ -f "/opt/system/Advanced/Switch to SD2 for Roms.sh" ] || [ -f "/boot/rk3326-rg351v-linux.dtb" ]; then
        SCREENW="640"
        SCREENH="480"
      fi
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      SCREENW="480"
      SCREENH="320"
	else
      SCREENW="480"
      SCREENH="320"
   fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
      SCREENW="640"
      SCREENH="480"
elif [[ -e "/dev/input/by-path/platform-gameforce-gamepad-event-joystick" ]]; then
      SCREENW="640"
      SCREENH="480"
elif [[ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG552" ]]; then
      SCREENW="1920"
      SCREENH="1152"
elif [ -e "/dev/input/by-path/platform-singleadc-joypad-event-joystick" ] || [ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG503" ]; then
      SCREENW="960"
      SCREENH="544"
else
      SCREENW="640"
      SCREENH="480"
fi

cd $GAMEDIR

$ESUDO chmod 666 /dev/tty0
$ESUDO chmod 666 /dev/tty1
$ESUDO chmod 666 /dev/uinput

# System
export LD_LIBRARY_PATH=$GAMEDIR/sdl12-compat:$GAMEDIR/gl4es:$GAMEDIR/lib

export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

# gl4es
export LIBGL_GL=15
export LIBGL_ES=1

# prep for clean log
$ESUDO rm $GAMEDIR/log.txt

# setup symbolic link to config directory
$ESUDO rm -rf ~/.hexen2
$ESUDO ln -s /$GAMEDIR/conf/.hexen2 ~/
$ESUDO chmod ugo+rw $GAMEDIR/conf/.hexen2/data1/config.cfg
$ESUDO chmod ugo+rw $GAMEDIR/conf/.hexen2/portals/config.cfg

$GPTOKEYB "glhexen2" -c "$GAMEDIR/hexen2.gptk" &
./glhexen2 -width $SCREENW -height $SCREENH $ADDLPARAMS -basedir ./ $RUNMOD 2>&1 | tee -a ./log.txt

$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
unset LD_LIBRARY_PATH
unset SDL_GAMECONTROLLERCONFIG
printf "\033c" > /dev/tty1
printf "\033c" > /dev/tty0
