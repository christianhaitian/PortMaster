#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "/roms/ports" ]; then
  controlfolder="/roms/ports/PortMaster"
 elif [ -d "/roms2/ports" ]; then
  controlfolder="/roms2/ports/PortMaster"
else
  controlfolder="/storage/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
source $controlfolder/tasksetter

get_controls

gameassembly="TMNT.exe"
gamedir="/$directory/ports/tmntsr"
cd "$gamedir/gamedata"

# Grab text output...
$ESUDO chmod 666 /dev/tty0
printf "\033c" > /dev/tty0
echo "Loading... Please Wait." > /dev/tty0

# Setup mono
monodir="$HOME/mono"
monofile="$controlfolder/libs/mono-6.12.0.122-aarch64.squashfs"
$ESUDO mkdir -p "$monodir"
$ESUDO umount "$monofile" || true
$ESUDO mount "$monofile" "$monodir"

# Setup savedir
$ESUDO rm -rf ~/.local/share/Tribute\ Games/TMNT
mkdir -p ~/.local/share/Tribute\ Games/
ln -sfv "$gamedir/savedata" ~/.local/share/Tribute\ Games/TMNT

# Remove all the dependencies in favour of system libs - e.g. the included 
rm -f System*.dll mscorlib.dll FNA.dll Mono.*.dll

# Setup path and other environment variables
# export FNA_PATCH="$gamedir/dlls/PanzerPaladinPatches.dll"
export XDG_DATA_HOME=$HOME/.local/share
export MONO_PATH="$gamedir/dlls":"$gamedir/gamedata":"$gamedir/monomod"
export LD_LIBRARY_PATH="$gamedir/libs":"$monodir/lib":"$LD_LIBRARY_PATH"
export PATH="$monodir/bin":"$PATH"

# Configure the renderpath
export FNA3D_FORCE_DRIVER=OpenGL
export FNA3D_OPENGL_FORCE_ES3=1
export FNA3D_OPENGL_FORCE_VBO_DISCARD=1
export FNA_SDL2_FORCE_BASE_PATH=0
regen_checksum=no

sha1sum -sc "${gamedir}/gamedata/.ver_checksum"
if [ $? -ne 0 ]; then
	echo "Checksum fail or unpatched binary found, patching game..." > /dev/tty0 2>&1
	rm -f "${gamedir}/gamedata/.astc_done"
	rm -f "${gamedir}/gamedata/.patch_done"
fi

# Textures not converted? let's perform first time setup
if [[ ! -f "${gamedir}/gamedata/.astc_done" ]]; then
	echo "Performing first time setup..." > /dev/tty0 2>&1
	echo "This may take upwards of 15 minutes (RK3326), go grab a pizza slice or two." > /dev/tty0 2>&1

	# Re-encode a few common textures as ASTC 4x4 due to RAM constraints.
	mono "${gamedir}/FNARepacker.exe" "${gamedir}/gamedata/Content/" > >(tee ${gamedir}/astc_log.txt) 2>&1
	
	# Mark step as done
	touch "${gamedir}/gamedata/.astc_done"
	regen_checksum=yes
fi

# MONOMODDED files not found, let's perform patching
if [[ ! -f "${gamedir}/gamedata/.patch_done" ]]; then
	echo "Performing game patching..." > /dev/tty0 2>&1

	# Configure MonoMod settings
	export MONOMOD_MODS="$gamedir/patches"
	export MONOMOD_DEPDIRS="${MONO_PATH}":"${gamedir}/monomod"

	# Patch the ParisEngine/gameassembly files
	mono "${gamedir}/monomod/MonoMod.exe" "${gamedir}/gamedata/ParisEngine.dll" > >(tee ${gamedir}/monomod_log.txt) 2>&1
	mono "${gamedir}/monomod/MonoMod.exe" "${gamedir}/gamedata/${gameassembly}" > >(tee -a ${gamedir}/monomod_log.txt) 2>&1
	if [ $? -ne 0 ]; then
		echo "Failure performing first time setup, report this." > /dev/tty0 2>&1
		sleep 5
		exit -1
	fi

	# Mark step as done
	touch "${gamedir}/gamedata/.patch_done"
	regen_checksum=yes
fi

# Regenerate sha1sum checks
if [[ x${regen_checksum} -eq xyes ]]; then
	sha1sum "${gamedir}/gamedata/"{ParisEngine.dll,TMNT.exe} > "${gamedir}/gamedata/.ver_checksum"
	sha1sum "${gamedir}/patches/"*.dll >> "${gamedir}/gamedata/.ver_checksum"
fi

printf "\033c" > /dev/tty0
echo "Loading... Please Wait." > /dev/tty0

$GPTOKEYB "mono" &
$TASKSET mono ../MMLoader.exe MONOMODDED_${gameassembly} > >(tee ${gamedir}/log.txt) 2>&1
$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
$ESUDO umount "$monodir"

# Disable console
printf "\033c" >> /dev/tty1
