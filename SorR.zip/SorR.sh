#!/bin/bash

ESUDO="sudo"
if [ -f "/storage/.config/.OS_ARCH" ]; then
  ESUDO=""
  alias sudo=""
fi

if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
  param_device="anbernic"
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      param_device="oga"
	else
	  param_device="rk2020"
	fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  param_device="ogs"
else
  param_device="chi"
fi

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  export LD_LIBRARY_PATH=/roms2/ports/sorr/libs:/usr/lib32:/usr/local/lib/arm-linux-gnueabihf/
  cd /roms2/ports/sorr
  $ESUDO ./oga_controls bgdi $param_device &
  ./bgdi $(find "/roms2/ports/sorr" -type f -iname "sorr.dat")
  $ESUDO kill -9 $(pidof oga_controls)
  unset LD_LIBRARY_PATH
  $ESUDO systemctl restart oga_events &
  printf "\033c" >> /dev/tty1
else
  export LD_LIBRARY_PATH=/roms/ports/sorr/libs:/usr/lib32:/usr/local/lib/arm-linux-gnueabihf/
  cd /roms/ports/sorr
  $ESUDO ./oga_controls bgdi $param_device &
  ./bgdi $(find "/roms/ports/sorr" -type f -iname "sorr.dat")
  $ESUDO kill -9 $(pidof oga_controls)
  unset LD_LIBRARY_PATH
  $ESUDO systemctl restart oga_events &
  printf "\033c" >> /dev/tty1
fi
