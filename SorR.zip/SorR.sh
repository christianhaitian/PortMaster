#!/bin/bash


if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
else
  controlfolder="/$directory/ports/PortMaster"
fi

source $controlfolder/control.txt

get_controls

export LD_LIBRARY_PATH=/$directory/ports/sorr/libs:/usr/lib32:/usr/local/lib/arm-linux-gnueabihf/
cd /$directory/ports/sorr
$ESUDO ./oga_controls bgdi $param_device &
./bgdi $(find "/$directory/ports/sorr" -type f -iname "sorr.dat")
$ESUDO kill -9 $(pidof oga_controls)
unset LD_LIBRARY_PATH
$ESUDO systemctl restart oga_events &
printf "\033c" >> /dev/tty1
fi
