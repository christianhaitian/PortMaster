#!/bin/bash

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "/roms/ports/PortMaster" ]; then
  controlfolder="/roms/ports/PortMaster"
elif [ -d "/roms2/ports/PortMaster" ]; then
  controlfolder="/roms2/ports/PortMaster"
else
  controlfolder="/storage/roms/ports/PortMaster"
fi

source "$controlfolder/control.txt"

get_controls

GAMEDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/quakespasm"
LIBDIR="$GAMEDIR/libs"

# Load directly into an expansion, a map, or a mod (Not sure if these were helping: -particles 100 -noadd -nocombine -nomtex)
RUNMOD="-game mg1 +map start"


if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
      SCREENW="480"
      SCREENH="320"
      GAMMA="0.80"
      if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ] || [ -f "/opt/system/Advanced/Switch to SD2 for Roms.sh" ] || [ -f "/boot/rk3326-rg351v-linux.dtb" ] || [ $(cat "/storage/.config/.OS_ARCH") == "RG351V" ]; then
        SCREENW="640"
        SCREENH="480"
        GAMMA="0.80"
      fi
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
      SCREENW="480"
      SCREENH="320"
      GAMMA="0.80"
	else
      param_device="rk2020"
      SCREENW="480"
      SCREENH="320"
      GAMMA="0.80"
	fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
      #SCREENW="854"  --The Odroid Go Super has a 848x480 display, but the RG351MP has a 640x480 res
      SCREENW="640"
      SCREENH="480"
      GAMMA="0.80"
elif [[ -e "/dev/input/by-path/platform-gameforce-gamepad-event-joystick" ]]; then
      SCREENW="640"
      SCREENH="480"
      GAMMA="0.80"
elif [[ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG552" ]]; then
      SCREENW="1920"
      SCREENH="1152"
      GAMMA="0.70"
elif [ -e "/dev/input/by-path/platform-singleadc-joypad-event-joystick" ] || [ "$(cat /sys/firmware/devicetree/base/model)" == "Anbernic RG503" ]; then
      #SCREENW="960"  --The RG503 has a 960x544 display, but the RG353s have a 640x480 res
      #SCREENH="544"
      SCREENW="640"
      SCREENH="480"
      GAMMA="0.70"
else
      SCREENW="640"
      SCREENH="480"
      GAMMA="0.80"
fi

cd $GAMEDIR


$ESUDO chmod 666 /dev/tty0
$ESUDO chmod 666 /dev/tty1
$ESUDO chmod 666 /dev/uinput

# System (Also prepare runtime directories for User and Pulse Audio)
export TERM=linux
export XDG_RUNTIME_DIR=/run/user/$UID/

$ESUDO mkdir -p /run/user/$UID
$ESUDO mkdir -p /run/user/$UID/pulse
$ESUDO chmod 755 /run/user/$UID
$ESUDO chmod 755 /run/user/$UID/pulse
$ESUDO chown $UID /run/user/$UID
$ESUDO chown $UID /run/user/$UID/pulse

export LD_LIBRARY_PATH=/$GAMEDIR/gl4es:$LIBDIR

export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

# gl4es
export LIBGL_NOBANNER=1
export LIBGL_SRGB=1
export LIBGL_NOTEST=1
export LIBGL_GL=15

$ESUDO rm $GAMEDIR/log.txt

printf "\033c" > /dev/tty0
echo " " > /dev/tty0
echo "Press 'L2' to QuickSave" > /dev/tty0
echo "Press 'R2' to QuickLoad" > /dev/tty0
echo " " > /dev/tty0
sleep 2

$GPTOKEYB "quakespasm" -c "$GAMEDIR/quakespasm.gptk" &
./quakespasm -width $SCREENW -height $SCREENH +gamma $GAMMA +scr_showfps 1 +joy_enable 0 +r_oldwater 1 +r_particles 1 +r_shadows 0 +r_sky_quality 6 $RUNMOD 2>&1 | tee $GAMEDIR/log.txt

$ESUDO kill -9 $(pidof gptokeyb)
$ESUDO systemctl restart oga_events &
pgrep -f quakespasm | sudo xargs kill -9
unset LD_LIBRARY_PATH
unset SDL_GAMECONTROLLERCONFIG
printf "\033c" > /dev/tty1
printf "\033c" >> /dev/tty1
printf "\033c" > /dev/tty0
