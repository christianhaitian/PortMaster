Quake 20 years anniversary - a new single player episode of Quake

Episode 5: Dimension of the past

START - Dimension of the Past - (Introduction level)

E5M1 - The Military Base - (Easy: 34, Normal: 43, Hard: 51) (Secrets: 6) 

E5M2 - The Power Supply - (Easy: 54, Normal: 69, Hard: 78) (Secrets: 5) 

E5M3 - The Dark Days - (Easy: 43, Normal: 53, Hard: 59) (Secrets: 5)

E5M4 - The Catacombs - (Easy: 58, Normal: 75, Hard: 86) (Secrets: 7)

E5M5 - The Stronghold - (Easy: 42, Normal: 54, Hard: 59) (Secrets: 5)

E5M6 - The Underworld - (Easy: 49, Normal: 61, Hard: 69) (Secrets: 4) 

E5M7 - The Otherworld - (Easy: 48, Normal: 63, Hard: 68) (Secrets: 5)

E5M8 - The House of Doom (Secret level) - (Easy: 32, Normal: 39, Hard: 45) (Secrets: 1)

E5END - The Year Zero - (Easy: 15, Normal: 20, Hard: 25) (Secrets: 2)

E5DM - The Theater of Doom (Deathmatch level (2-6 players))


Editor used: Worldcraft


Installation:
	Create a "dopa" folder in your Quake directory
	Extract all files to the new folder: \Quake\dopa 
	Start the dopa.bat file (new demo indicates it started correctly)
	Start a new game

Have fun!

MachineGames
contact@machinegames.com

June 22, 2016